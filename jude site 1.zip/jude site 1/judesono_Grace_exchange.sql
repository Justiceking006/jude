-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jul 16, 2025 at 10:49 PM
-- Server version: 10.5.29-MariaDB
-- PHP Version: 8.3.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `judesono_Grace_exchange`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity_logs`
--

CREATE TABLE `activity_logs` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `action` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `activity_logs`
--

INSERT INTO `activity_logs` (`id`, `user_id`, `action`, `description`, `created_at`) VALUES
(1, 1, 'Login', 'User logged in successfully.', '2025-07-10 02:09:33'),
(2, 1, 'Logout', 'User logged out.', '2025-07-10 02:10:48'),
(3, 1, 'Login', 'User logged in successfully.', '2025-07-10 02:10:51'),
(4, 1, 'Logout', 'User logged out.', '2025-07-10 02:21:24'),
(5, 2, 'Login', 'User logged in successfully.', '2025-07-10 02:21:28'),
(6, 2, 'Logout', 'User logged out.', '2025-07-10 02:21:59'),
(7, 2, 'Login', 'User logged in successfully.', '2025-07-10 02:22:04'),
(8, 2, 'Logout', 'User logged out.', '2025-07-10 02:22:15'),
(9, 1, 'Login', 'User logged in successfully.', '2025-07-10 02:22:19'),
(10, 1, 'Logout', 'User logged out.', '2025-07-10 02:32:18'),
(11, 1, 'Login', 'User logged in successfully.', '2025-07-10 02:32:21'),
(12, 1, 'Login', 'User logged in successfully.', '2025-07-10 02:35:38'),
(13, 1, 'Login', 'User logged in successfully.', '2025-07-10 08:25:30'),
(14, 3, 'Login', 'User logged in successfully.', '2025-07-10 10:41:44'),
(15, 3, 'Logout', 'User logged out.', '2025-07-10 10:43:03'),
(16, 3, 'Login', 'User logged in successfully.', '2025-07-10 10:43:24'),
(17, 3, 'Login', 'User logged in successfully.', '2025-07-10 10:43:25'),
(18, 4, 'Login', 'User logged in successfully.', '2025-07-10 10:48:37'),
(19, 6, 'Login', 'User logged in successfully.', '2025-07-10 13:10:05'),
(20, 6, 'Login', 'User logged in successfully.', '2025-07-10 13:10:06'),
(21, 6, 'Logout', 'User logged out.', '2025-07-10 13:10:22'),
(22, 8, 'Login', 'User logged in successfully.', '2025-07-11 13:40:02'),
(23, 8, 'Logout', 'User logged out.', '2025-07-11 14:07:59'),
(24, 9, 'Login', 'User logged in successfully.', '2025-07-11 14:08:34'),
(25, 9, 'Logout', 'User logged out.', '2025-07-11 14:23:30'),
(26, 10, 'Login', 'User logged in successfully.', '2025-07-11 14:24:10'),
(27, 3, 'Login', 'User logged in successfully.', '2025-07-11 16:43:07'),
(28, 3, 'Login', 'User logged in successfully.', '2025-07-11 16:43:08'),
(29, 3, 'Login', 'User logged in successfully.', '2025-07-13 19:40:58'),
(30, 3, 'Login', 'User logged in successfully.', '2025-07-13 19:41:00'),
(31, 11, 'Login', 'User logged in successfully.', '2025-07-14 20:20:22'),
(32, 12, 'Login', 'User logged in successfully.', '2025-07-15 19:11:58'),
(33, 10, 'Login', 'User logged in successfully.', '2025-07-15 20:16:54'),
(34, 10, 'Login', 'User logged in successfully.', '2025-07-15 20:16:55'),
(35, 12, 'Login', 'User logged in successfully.', '2025-07-15 20:48:39'),
(36, 10, 'Logout', 'User logged out.', '2025-07-15 21:04:30'),
(37, 9, 'Login', 'User logged in successfully.', '2025-07-15 21:04:33'),
(38, 9, 'Logout', 'User logged out.', '2025-07-15 21:04:44'),
(39, 2, 'Login', 'User logged in successfully.', '2025-07-15 21:04:52'),
(40, 12, 'Login', 'User logged in successfully.', '2025-07-15 21:39:37'),
(41, 12, 'Login', 'User logged in successfully.', '2025-07-16 03:35:11'),
(42, 3, 'Login', 'User logged in successfully.', '2025-07-16 06:22:36'),
(43, 3, 'Login', 'User logged in successfully.', '2025-07-16 06:22:36'),
(44, 2, 'Login', 'User logged in successfully.', '2025-07-16 09:34:34'),
(45, 2, 'Login', 'User logged in successfully.', '2025-07-16 09:43:33'),
(46, 11, 'Login', 'User logged in successfully.', '2025-07-16 20:53:44'),
(47, 12, 'Login', 'User logged in successfully.', '2025-07-16 22:09:35');

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `email`, `password`, `name`, `phone`, `created_at`) VALUES
(1, 'admin@yourdomain.com', '$2y$10$jV/EhtBl3aeqo8fRY9pZruam/RLNKTvT4UUSzZjtQMNMFsu27URHi', 'Super Admin', '+2348108255139', '2025-07-16 13:35:41');

-- --------------------------------------------------------

--
-- Table structure for table `faqs`
--

CREATE TABLE `faqs` (
  `id` int(11) NOT NULL,
  `question` text NOT NULL,
  `answer` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `faqs`
--

INSERT INTO `faqs` (`id`, `question`, `answer`, `created_at`) VALUES
(1, 'How do I fund my wallet?', 'Go to your dashboard and click \"Fund Wallet\". Choose a payment method, follow the instructions, and your wallet will be credited.', '2025-07-10 01:50:16'),
(2, 'How long does it take to reflect wallet funding?', 'Wallet funding via API is instant. Manual payments (bank transfer or WhatsApp confirmation) may take up to 10 minutes.', '2025-07-10 01:50:16'),
(3, 'What can I use my wallet balance for?', 'You can use your balance to purchase data, airtime, pay electricity bills, subscribe to TV plans, or fund other services.', '2025-07-10 01:50:16'),
(4, 'Can I withdraw from my wallet?', 'Withdrawals are only available for approved agents and users with referral earnings. Contact support if you need a withdrawal.', '2025-07-10 01:50:16'),
(5, 'How does the referral system work?', 'Each user has a unique referral link. When someone signs up using your link and makes transactions, you earn a commission.', '2025-07-10 01:50:16'),
(6, 'Where can I find my referral link?', 'Go to the \"More\" section of your dashboard and click on \"Referrals\". You will see your referral link and downline list.', '2025-07-10 01:50:16'),
(7, 'When do I receive referral earnings?', 'Referral commissions are credited instantly after a successful transaction by your referred user.', '2025-07-10 01:50:16'),
(8, 'Can I buy data and airtime for any network?', 'Yes, we support MTN, Glo, Airtel, and 9mobile for both data and airtime purchases.', '2025-07-10 01:50:16'),
(9, 'How do I order a POS machine?', 'Click on \"POS Device\" under the services section. Fill in your details and click \"Contact via WhatsApp\" to place your order.', '2025-07-10 01:50:16'),
(10, 'Is CAC registration available?', 'Yes. We offer CAC registration services. Go to \"CAC Registration\" on your dashboard and submit your request via WhatsApp.', '2025-07-10 01:50:16'),
(11, 'How do I fund my wallet?', 'Go to your dashboard and click \"Fund Wallet\", choose payment method, and follow instructions.', '2025-07-10 01:50:26'),
(12, 'How do I earn from referrals?', 'Share your referral link. When someone signs up and transacts, you earn commission.', '2025-07-10 01:50:26');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `user_id`, `title`, `message`, `is_read`, `created_at`) VALUES
(1, 1, 'Welcome!', 'Thanks for joining Son of Grace Exchange.', 1, '2025-07-10 02:20:54'),
(2, 1, 'Promo', 'Top up your wallet today and earn bonus.', 1, '2025-07-10 02:20:54'),
(3, 1, 'Reminder', 'Don’t forget to verify your email.', 1, '2025-07-10 02:20:54'),
(4, 3, '? Welcome to Son of Grace Exchange!', 'Hi UGOCHUKWU, your account has been created successfully. You can now buy airtime, data, pay bills, and earn from referrals using your dashboard.', 1, '2025-07-10 10:41:39'),
(5, 4, '? Welcome to Son of Grace Exchange!', 'Hi Justice j, your account has been created successfully. You can now buy airtime, data, pay bills, and earn from referrals using your dashboard.', 1, '2025-07-10 10:47:23'),
(7, 6, '? Welcome to Son of Grace Exchange!', 'Hi Jax, your account has been created.', 0, '2025-07-10 13:09:49'),
(9, 8, '? Welcome to Son of Grace Exchange!', 'Hi Kemi, your account has been created.', 1, '2025-07-11 13:39:56'),
(10, 9, '? Welcome to Son of Grace Exchange!', 'Hi King, your account has been created.', 1, '2025-07-11 14:08:23'),
(11, 10, '?? Wallet Error', '? Failed to get Monnify token.', 1, '2025-07-11 14:24:04'),
(12, 10, '? Welcome to Son of Grace Exchange!', 'Hi Jane, your account has been created.', 1, '2025-07-11 14:24:04'),
(13, 11, '?? Wallet Error', '? Failed to get Monnify token.', 0, '2025-07-14 20:19:34'),
(14, 11, '? Welcome to Son of Grace Exchange!', 'Hi DANIEL, your account has been created.', 0, '2025-07-14 20:19:34'),
(15, 12, '?? Wallet Error', '? Failed to get Monnify token.', 1, '2025-07-15 19:11:41'),
(16, 12, '? Welcome to Son of Grace Exchange!', 'Hi Jude Eze, your account has been created.', 1, '2025-07-15 19:11:41');

-- --------------------------------------------------------

--
-- Table structure for table `policies`
--

CREATE TABLE `policies` (
  `id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `content` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `policies`
--

INSERT INTO `policies` (`id`, `title`, `content`, `created_at`) VALUES
(1, 'Terms of Service', 'Your terms here...', '2025-07-10 00:57:39'),
(2, 'Privacy Policy', 'Your privacy terms here...', '2025-07-10 00:57:39'),
(3, 'Refund Policy', 'Your refund policy...', '2025-07-10 00:57:39'),
(4, 'Terms of Service', 'By using Son of Grace Exchange, you agree to comply with our terms. Any misuse may result in suspension.', '2025-07-10 01:53:29'),
(5, 'Privacy Policy', 'We collect minimal data to provide services. Your personal info is never sold or shared without consent.', '2025-07-10 01:53:29'),
(6, 'Refund Policy', 'All VTU payments are final. In case of failed service delivery, contact support within 24 hours for resolution.', '2025-07-10 01:53:29'),
(7, 'Account Termination Policy', 'We reserve the right to suspend or terminate accounts found to be in violation of our terms, including fraudulent transactions or abuse of the referral system.', '2025-07-10 01:58:47'),
(8, 'Service Availability', 'While we strive for 99.9% uptime, Son of Grace Exchange cannot guarantee uninterrupted access. Downtime may occur for maintenance or third-party failures.', '2025-07-10 01:58:47'),
(9, 'User Conduct', 'Users must refrain from abusive language, impersonation, or misuse of the platform. Violators may be permanently banned without refund.', '2025-07-10 01:58:47'),
(10, 'Referral Program Policy', 'Referral bonuses are credited only when referred users complete verified transactions. Any attempt to self-refer or game the system will lead to disqualification.', '2025-07-10 01:58:47'),
(11, 'Payment Dispute Resolution', 'In case of failed transactions or double debits, users must report within 24 hours. Disputes will be investigated and resolved within 48–72 business hours.', '2025-07-10 01:58:47'),
(12, 'Data Retention Policy', 'Your transaction records and personal data are retained for audit and regulatory purposes. You may request deletion after account closure, subject to legal limitations.', '2025-07-10 01:58:47'),
(13, 'Refund Eligibility', 'Refunds are processed only for failed services confirmed by our provider APIs. Data and airtime once delivered are not refundable.', '2025-07-10 01:58:47'),
(14, 'Third-Party Services Disclaimer', 'We integrate APIs from verified third-party providers. While we ensure reliability, we are not liable for external service failures beyond our control.', '2025-07-10 01:58:47'),
(15, 'Security Measures', 'We implement secure password hashing, encrypted sessions, and manual review of sensitive actions. Never share your login details with anyone.', '2025-07-10 01:58:47'),
(16, 'Policy Updates', 'These policies are subject to change. Users will be notified of critical updates via dashboard notifications or email.', '2025-07-10 01:58:47');

-- --------------------------------------------------------

--
-- Table structure for table `pos_requests`
--

CREATE TABLE `pos_requests` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `business_name` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `pos_requests`
--

INSERT INTO `pos_requests` (`id`, `user_id`, `name`, `phone`, `email`, `business_name`, `created_at`) VALUES
(1, 2, 'Justice King', '08161431114', 'justiceking006@gmail.com', 'Jusytech', '2025-07-15 22:00:18'),
(2, 2, 'Justice King', '08161431114', 'justiceking006@gmail.com', 'Jusytech', '2025-07-16 09:34:46');

-- --------------------------------------------------------

--
-- Table structure for table `referrals`
--

CREATE TABLE `referrals` (
  `id` int(11) NOT NULL,
  `referrer_id` int(11) DEFAULT NULL,
  `referred_id` int(11) DEFAULT NULL,
  `earned_amount` decimal(10,2) DEFAULT 0.00,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `earnings` decimal(10,2) DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `id` int(11) NOT NULL,
  `category` varchar(50) DEFAULT NULL,
  `network` varchar(50) DEFAULT NULL,
  `plan_name` varchar(100) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `service_id` varchar(20) DEFAULT NULL,
  `user_price` decimal(10,2) DEFAULT NULL,
  `reseller_price` decimal(10,2) DEFAULT NULL,
  `api_user_price` decimal(10,2) DEFAULT NULL,
  `validity` varchar(50) DEFAULT NULL,
  `unit_type` varchar(20) DEFAULT 'naira',
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `category`, `network`, `plan_name`, `type`, `service_id`, `user_price`, `reseller_price`, `api_user_price`, `validity`, `unit_type`, `status`, `created_at`) VALUES
(1, 'Buy Data', 'MTN', '500MB', 'CG', '15', 160.00, 160.00, 160.00, '30 Days', 'naira', 'active', '2025-07-16 11:45:31'),
(2, 'Buy Data', 'MTN', '1GB', 'CG', '16', 270.00, 268.00, 260.00, '30 Days', 'naira', 'active', '2025-07-16 11:45:31'),
(3, 'Buy Data', 'MTN', '2GB', 'CG', '17', 560.00, 558.00, 530.00, '30 Days', 'naira', 'active', '2025-07-16 11:45:31'),
(4, 'Buy Data', 'MTN', '5GB', 'CG', '18', 1410.00, 1405.00, 1325.00, '30 Days', 'naira', 'active', '2025-07-16 11:45:31'),
(5, 'Buy Data', 'MTN', '10GB', 'CG', '19', 2750.00, 2745.00, 2650.00, '30 Days', 'naira', 'active', '2025-07-16 11:45:31'),
(6, 'Buy Data', 'MTN', '20GB', 'CG', '190', 5570.00, 5570.00, 5300.00, '30 Days', 'naira', 'active', '2025-07-16 11:45:31'),
(7, 'Buy Data', 'GLO', '1.05GB', 'DIRECT', '20', 500.00, 500.00, 500.00, '30 Days', 'naira', 'active', '2025-07-16 14:39:48'),
(8, 'Buy Data', 'AIRTEL', '750MB', 'DIRECT', '47', 1250.00, 1250.00, 1250.00, '30 Days', 'naira', 'active', '2025-07-16 14:39:48'),
(9, 'Buy Data', '9mobile', '500MB', 'DIRECT', '30', 450.00, 450.00, 450.00, '30 Days', 'naira', 'active', '2025-07-16 14:39:48'),
(10, 'Exam Pins', 'WAEC', 'WAEC', 'NA', '1', 3550.00, 3550.00, 3550.00, 'NA', 'naira', 'active', '2025-07-16 15:51:40'),
(11, 'Exam Pins', 'NECO', 'NECO', 'NA', '2', 1400.00, 1400.00, 1400.00, 'NA', 'naira', 'active', '2025-07-16 15:51:40'),
(12, 'Exam Pins', 'NABTEB', 'NABTEB', 'NA', '3', 1050.00, 1050.00, 1050.00, 'NA', 'naira', 'active', '2025-07-16 15:51:40'),
(13, 'Electricity', 'PHED', 'Port Harcourt Electricity', '', '4', 0.00, 0.00, 0.00, '', 'percent', 'active', '2025-07-16 15:51:40'),
(14, 'Bulk SMS', 'GENERAL', 'Bulk SMS', 'NA', 'NA', 0.00, 0.00, 0.00, 'NA', 'percent', 'active', '2025-07-16 15:52:14'),
(15, 'Cable', 'dstv', 'dstv padi', '', '90', 3700.00, 3700.00, 3700.00, '', 'naira', 'active', '2025-07-16 15:52:26'),
(16, 'Cable', 'dstv', 'dstv yanga', '', '91', 5200.00, 5200.00, 5200.00, '', 'naira', 'active', '2025-07-16 15:52:26'),
(17, 'Cable', 'dstv', 'dstv confam', '', '92', 9500.00, 9500.00, 9500.00, '', 'naira', 'active', '2025-07-16 15:52:26'),
(18, 'Cable', 'dstv', 'dstv compact', '', '93', 15800.00, 15800.00, 15800.00, '', 'naira', 'active', '2025-07-16 15:52:26'),
(19, 'Cable', 'dstv', 'dstv compact plus', '', '105', 25200.00, 25200.00, 25200.00, '', 'naira', 'active', '2025-07-16 15:52:26'),
(20, 'Cable', 'dstv', 'dstv premium', '', '106', 37200.00, 37200.00, 37200.00, '', 'naira', 'active', '2025-07-16 15:52:26'),
(21, 'Cable', 'gotv', 'gotv smallie', '', '94', 1650.00, 1650.00, 1650.00, '', 'naira', 'active', '2025-07-16 15:52:26'),
(22, 'Cable', 'gotv', 'gotv smallie quaterly', '', '98', 4300.00, 4300.00, 4300.00, '', 'naira', 'active', '2025-07-16 15:52:26'),
(23, 'Cable', 'gotv', 'gotv smallie yearly', '', '99', 12400.00, 12400.00, 12350.00, '', 'naira', 'active', '2025-07-16 15:52:26'),
(24, 'Cable', 'gotv', 'gotv jolli', '', '96', 5000.00, 5000.00, 5000.00, '', 'naira', 'active', '2025-07-16 15:52:26'),
(25, 'Cable', 'gotv', 'gotv jinja', '', '97', 3450.00, 3450.00, 3450.00, '', 'naira', 'active', '2025-07-16 15:52:26'),
(26, 'Cable', 'gotv', 'gotv max', '', '95', 7300.00, 7300.00, 7300.00, '', 'naira', 'active', '2025-07-16 15:52:26'),
(27, 'Cable', 'gotv', 'gotv supa', '', '112', 9750.00, 9750.00, 9750.00, '', 'naira', 'active', '2025-07-16 15:52:26'),
(28, 'Cable', 'startimes', 'startimes nova', '', '100', 1800.00, 1800.00, 1800.00, '', 'naira', 'active', '2025-07-16 15:52:26'),
(29, 'Cable', 'startimes', 'startimes basic', '', '101', 3150.00, 3150.00, 3150.00, '', 'naira', 'active', '2025-07-16 15:52:26'),
(30, 'Cable', 'startimes', 'startimes smart', '', '102', 4000.00, 4000.00, 4000.00, '', 'naira', 'active', '2025-07-16 15:52:26'),
(31, 'Cable', 'startimes', 'startimes super', '', '104', 7600.00, 7600.00, 7600.00, '', 'naira', 'active', '2025-07-16 15:52:26'),
(32, 'Electricity', 'JED', 'Jos Electricity', '', '5', 0.00, 0.00, 0.00, '', 'percent', 'active', '2025-07-16 15:52:39'),
(33, 'Electricity', 'IBEDC', 'Ibadan Electricity', '', '6', 0.00, 0.00, 0.00, '', 'percent', 'active', '2025-07-16 15:52:39'),
(34, 'Electricity', 'KAEDCO', 'Kaduna Electricity', '', '7', 0.00, 0.00, 0.00, '', 'percent', 'active', '2025-07-16 15:52:39'),
(35, 'Electricity', 'AEDC', 'Abuja Electricity', '', '8', 0.00, 0.00, 0.00, '', 'percent', 'active', '2025-07-16 15:52:39'),
(36, 'Electricity', 'EEDC', 'Enugu Electricity', '', '9', 0.00, 0.00, 0.00, '', 'percent', 'active', '2025-07-16 15:52:50'),
(37, 'Buy Data', 'MTN', '230MB 1DAYS', 'DIRECT', '196', 220.00, 219.00, 218.00, '30 Days', 'naira', 'active', '2025-07-16 15:53:19'),
(38, 'Buy Data', 'MTN', '500MB 7DAYS', 'DIRECT', '491', 510.00, 509.00, 508.00, '30 Days', 'naira', 'active', '2025-07-16 15:53:19'),
(39, 'Buy Data', 'MTN', '1.0GB 1DAYS', 'DIRECT', '652', 520.00, 519.00, 518.00, '30 Days', 'naira', 'active', '2025-07-16 15:53:19'),
(40, 'Buy Data', 'MTN', '1.0GB 7DAYS + 25MIN', 'DIRECT', '786', 795.00, 794.00, 793.00, '30 Days', 'naira', 'active', '2025-07-16 15:53:19'),
(41, 'Buy Data', 'MTN', '2.0GB 30DAYS + 2MIN', 'DIRECT', '716', 1500.00, 1499.00, 1498.00, '30 Days', 'naira', 'active', '2025-07-16 15:53:19'),
(42, 'Buy Data', 'MTN', '3.2GB 2DAYS', 'DIRECT', '434', 1100.00, 1099.00, 1098.00, '30 Days', 'naira', 'active', '2025-07-16 15:53:19'),
(43, 'Buy Data', 'MTN', '3.5GB 30DAYS', 'DIRECT', '159', 2500.00, 2499.00, 2498.00, '30 Days', 'naira', 'active', '2025-07-16 15:53:19'),
(44, 'Buy Data', 'MTN', '6.0GB 7DAYS', 'DIRECT', '027', 2600.00, 2599.00, 2598.00, '30 Days', 'naira', 'active', '2025-07-16 15:53:19'),
(45, 'Buy Data', 'MTN', '7.0GB 30DAYS + 2GB', 'DIRECT', '098', 3480.00, 3479.00, 3478.00, '30 Days', 'naira', 'active', '2025-07-16 15:53:19'),
(46, 'Buy Data', 'MTN', '11.0GB 7DAYS', 'DIRECT', '003', 3600.00, 3599.00, 3598.00, '30 Days', 'naira', 'active', '2025-07-16 15:53:19'),
(47, 'Buy Data', 'MTN', '75.0GB 30DAYS', 'DIRECT', '023', 20100.00, 20099.00, 20098.00, '30 Days', 'naira', 'active', '2025-07-16 15:53:19'),
(48, 'Buy Data', 'MTN', '1.0GB', 'SME2', '991', 100.00, 99.00, 98.00, '30 Days', 'naira', 'active', '2025-07-16 15:53:19'),
(49, 'Buy Data', 'MTN', '500MB', 'SME', '590', 460.00, 459.00, 458.00, '30 Days', 'naira', 'active', '2025-07-16 15:53:19'),
(50, 'Buy Data', 'MTN', '1.0GB', 'SME', '647', 670.00, 669.00, 668.00, '30 Days', 'naira', 'active', '2025-07-16 15:53:19'),
(51, 'Buy Data', 'MTN', '2.0GB', 'SME', '096', 1300.00, 1299.00, 1298.00, '30 Days', 'naira', 'active', '2025-07-16 15:53:19'),
(52, 'Buy Data', 'MTN', '3.0GB', 'SME', '607', 2000.00, 1999.00, 1998.00, '30 Days', 'naira', 'active', '2025-07-16 15:53:19'),
(53, 'Buy Data', 'MTN', '5.0GB', 'SME', '372', 2600.00, 2599.00, 2598.00, '30 Days', 'naira', 'active', '2025-07-16 15:53:19'),
(54, 'Buy Data', 'GLO', '2.5GB', 'DIRECT', '21', 980.00, 980.00, 980.00, '30 Days', 'naira', 'active', '2025-07-16 15:53:19'),
(55, 'Buy Data', 'GLO', '4.1GB', 'DIRECT', '22', 2300.00, 2300.00, 2300.00, '30 Days', 'naira', 'active', '2025-07-16 15:53:19'),
(56, 'Buy Data', 'GLO', '7.7GB', 'DIRECT', '23', 1910.00, 1910.00, 1910.00, '30 Days', 'naira', 'active', '2025-07-16 15:53:19'),
(57, 'Buy Data', 'GLO', '10.0GB', 'DIRECT', '24', 2400.00, 2400.00, 2400.00, '30 Days', 'naira', 'active', '2025-07-16 15:53:19'),
(58, 'Buy Data', 'GLO', '200MB 14Days', 'CG', '655', 100.00, 99.00, 98.00, '30 Days', 'naira', 'active', '2025-07-16 15:53:19'),
(59, 'Buy Data', 'GLO', '500MB 30Days', 'CG', '819', 230.00, 229.00, 228.00, '30 Days', 'naira', 'active', '2025-07-16 15:53:19'),
(60, 'Buy Data', 'GLO', '1.0GB 30Days', 'CG', '468', 460.00, 459.00, 458.00, '30 Days', 'naira', 'active', '2025-07-16 15:53:19'),
(61, 'Buy Data', 'GLO', '2.0GB 30Days', 'CG', '983', 950.00, 949.00, 948.00, '30 Days', 'naira', 'active', '2025-07-16 15:53:19'),
(62, 'Buy Data', 'GLO', '3.0GB 30Days', 'CG', '653', 1380.00, 1379.00, 1378.00, '30 Days', 'naira', 'active', '2025-07-16 15:53:19'),
(63, 'Buy Data', 'GLO', '5.0GB 30Days', 'CG', '793', 2280.00, 2279.00, 2278.00, '30 Days', 'naira', 'active', '2025-07-16 15:53:19'),
(64, 'Buy Data', 'GLO', '10.0GB 30Days', 'CG', '998', 4600.00, 4599.00, 4598.00, '30 Days', 'naira', 'active', '2025-07-16 15:53:19'),
(65, 'Buy Data', 'AIRTEL', '1.5GB', 'DIRECT', '485', 1650.00, 1650.00, 1560.00, '30 Days', 'naira', 'active', '2025-07-16 15:53:19'),
(66, 'Buy Data', 'AIRTEL', '2GB', 'DIRECT', '46', 1750.00, 1790.00, 1780.00, '30 Days', 'naira', 'active', '2025-07-16 15:53:19'),
(67, 'Buy Data', 'AIRTEL', '3GB', 'DIRECT', '39', 2560.00, 2880.00, 2780.00, '30 Days', 'naira', 'active', '2025-07-16 15:53:19'),
(68, 'Buy Data', 'AIRTEL', '20GB', 'DIRECT', '52', 4700.00, 5670.00, 5700.00, '30 Days', 'naira', 'active', '2025-07-16 15:53:19'),
(69, 'Buy Data', '9mobile', '1.5GB', 'DIRECT', '31', 855.00, 855.00, 855.00, '30 Days', 'naira', 'active', '2025-07-16 15:53:19'),
(70, 'Buy Data', '9mobile', '2GB', 'DIRECT', '32', 1000.00, 1000.00, 1000.00, '30 Days', 'naira', 'active', '2025-07-16 15:53:19'),
(71, 'Buy Data', '9mobile', '4.5GB', 'DIRECT', '33', 1700.00, 1700.00, 1700.00, '30 Days', 'naira', 'active', '2025-07-16 15:53:19'),
(72, 'Buy Data', '9mobile', '11GB', 'DIRECT', '34', 3520.00, 3520.00, 3520.00, '30 Days', 'naira', 'active', '2025-07-16 15:53:19'),
(73, 'Buy Data', '9mobile', '1GB', 'SME', '54', 87.00, 48.00, 78.00, '30 Days', 'naira', 'active', '2025-07-16 15:53:19'),
(74, 'Buy Data', '9mobile', '2GB', 'SME', '55', 88.00, 88.00, 88.00, '30 Days', 'naira', 'active', '2025-07-16 15:53:19'),
(75, 'Buy Data', '9mobile', '3GB', 'SME', '56', 48.00, 58.00, 87.00, '30 Days', 'naira', 'active', '2025-07-16 15:53:19'),
(76, 'Buy Data', '9mobile', '5GB', 'SME', '57', 48.00, 48.00, 18.00, '30 Days', 'naira', 'active', '2025-07-16 15:53:19'),
(77, 'Buy Data', '9mobile', '10GB', 'SME', '58', 848.00, 48.00, 18.00, '30 Days', 'naira', 'active', '2025-07-16 15:53:19'),
(78, 'Buy Data', '9mobile', '25MB 30Days', 'CG', '936', 40.00, 39.00, 38.00, '30 Days', 'naira', 'active', '2025-07-16 15:53:19'),
(79, 'Buy Data', '9mobile', '100MB 30Days', 'CG', '927', 70.00, 69.00, 68.00, '30 Days', 'naira', 'active', '2025-07-16 15:53:19'),
(80, 'Buy Data', '9mobile', '500MB 30Days', 'CG', '197', 156.00, 155.00, 154.00, '30 Days', 'naira', 'active', '2025-07-16 15:53:19'),
(81, 'Buy Data', '9mobile', '1.0GB 30Days', 'CG', '761', 293.00, 292.00, 291.00, '30 Days', 'naira', 'active', '2025-07-16 15:53:19'),
(82, 'Buy Data', '9mobile', '1.5GB 30Days', 'CG', '426', 459.00, 458.00, 457.00, '30 Days', 'naira', 'active', '2025-07-16 15:53:19'),
(83, 'Buy Data', '9mobile', '2.0GB 30Days', 'CG', '012', 596.00, 595.00, 594.00, '30 Days', 'naira', 'active', '2025-07-16 15:53:19'),
(84, 'Buy Data', '9mobile', '3.0GB 30Days', 'CG', '533', 870.00, 869.00, 868.00, '30 Days', 'naira', 'active', '2025-07-16 15:53:19'),
(85, 'Buy Data', '9mobile', '4.0GB 30Days', 'CG', '223', 1160.00, 1159.00, 1158.00, '30 Days', 'naira', 'active', '2025-07-16 15:53:19'),
(86, 'Buy Data', '9mobile', '5.0GB 30Days', 'CG', '497', 1500.00, 1499.00, 1498.00, '30 Days', 'naira', 'active', '2025-07-16 15:53:19'),
(87, 'Buy Data', '9mobile', '10.0GB 30Days', 'CG', '097', 2900.00, 2899.00, 2898.00, '30 Days', 'naira', 'active', '2025-07-16 15:53:19'),
(88, 'Buy Data', '9mobile', '15.0GB 30Days', 'CG', '965', 4300.00, 4299.00, 4298.00, '30 Days', 'naira', 'active', '2025-07-16 15:53:19'),
(89, 'Buy Data', '9mobile', '20.0GB 30Days', 'CG', '075', 5700.00, 5699.00, 5698.00, '30 Days', 'naira', 'active', '2025-07-16 15:53:19');

-- --------------------------------------------------------

--
-- Table structure for table `shares`
--

CREATE TABLE `shares` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `platform` varchar(50) DEFAULT NULL,
  `shared_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `service` varchar(50) DEFAULT NULL,
  `provider` varchar(100) DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `status` enum('pending','successful','failed') DEFAULT 'pending',
  `metadata` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `category` varchar(50) DEFAULT 'general',
  `reference` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `referral_code` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `phone`, `first_name`, `password`, `created_at`, `referral_code`) VALUES
(1, 'justiceking006@gmail.com', '08161431114', 'Justice king', '$2y$10$KXKWOl9MdcjO6nl.q1ZryuclAehhnRWQlcXPLw/DZWjmELT64gnDK', '2025-07-09 21:25:21', NULL),
(2, 'Joseph@gmail.com', '08165790445', 'Joseph', '$2y$10$UkhX12BLrsDAxI9i8/zRPOy195dSWjXg9Ohbklct/qYrmv/duehJ6', '2025-07-10 00:13:36', NULL),
(3, 'ugojah007@gmail.com', '08089543875', 'UGOCHUKWU', '$2y$10$FDbIeGteKQxJhvuXTL8RR.Pea4leXpaQI/TB2QLz5vfFBU9.M57MC', '2025-07-10 10:41:39', 'S1DO5Z'),
(4, 'rex@gmail.com', '08794651234', 'Justice j', '$2y$10$4NYNheZy5bpSM2jwJBKplOwSRvPR2/ylozgornvAh.mKPxRip7HZe', '2025-07-10 10:47:23', 'ZHM7BX'),
(6, 'jax@gmail.com', '08796452816', 'Jax', '$2y$10$ths5ru/LWFd4GExnOMqXxePUKQc319fBa77Bx/zmdcDzc7C01.wme', '2025-07-10 13:09:49', 'UPSOMA'),
(8, 'kemi@gmail.com', '08075481254', 'Kemi', '$2y$10$yBwpzNsXMQ.bQIrw6t3lx.IIkLQHglTtazFPYkl2iU4E2HdC.4vZi', '2025-07-11 13:39:56', '0EIZQM'),
(9, 'king@gmail.com', '08796482188', 'King', '$2y$10$P6hUNVye1M4MroOTqAMPJ.fhRuDQDuJU/qdl8tAEL4Z1y0XgEPoyC', '2025-07-11 14:08:22', 'CW0S5T'),
(10, 'jane@gmail.com', '087946524805', 'Jane', '$2y$10$QXZSTdHyp7ToMzDqIN5UWeUocgSeyOOtMV3J7SKiytM65pF2AfCXK', '2025-07-11 14:24:03', 'TUKP8S'),
(11, 'danieltimilehin836@gmail.com', '08159356071', 'DANIEL', '$2y$10$/uKr1RAn2VS4vaB8/94roeB7x73qaw.7dQ844fiunGM8yu9zI8UkK', '2025-07-14 20:19:33', 'OV1QWI'),
(12, 'ezejudeuzoma02@gmail.com', '09137981321', 'Jude Eze', '$2y$10$WELirhiKcUlQqNAsVJw8mOiVEOgJipoq52BuLMPN.rn8TSP3mdDgK', '2025-07-15 19:11:40', 'U2R8HG');

-- --------------------------------------------------------

--
-- Table structure for table `wallets`
--

CREATE TABLE `wallets` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `balance` decimal(10,2) DEFAULT 0.00,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `account_number` varchar(20) DEFAULT NULL,
  `bank_name` varchar(100) DEFAULT NULL,
  `account_reference` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `wallets`
--

INSERT INTO `wallets` (`id`, `user_id`, `balance`, `updated_at`, `account_number`, `bank_name`, `account_reference`) VALUES
(2, 8, 0.00, '2025-07-11 14:02:20', '1234567890', 'Monnify Bank', 'SOGX-MANUAL-7');

-- --------------------------------------------------------

--
-- Table structure for table `withdrawals`
--

CREATE TABLE `withdrawals` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activity_logs`
--
ALTER TABLE `activity_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `faqs`
--
ALTER TABLE `faqs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `policies`
--
ALTER TABLE `policies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pos_requests`
--
ALTER TABLE `pos_requests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `referrals`
--
ALTER TABLE `referrals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `referrer_id` (`referrer_id`),
  ADD KEY `referred_id` (`referred_id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shares`
--
ALTER TABLE `shares`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `reference` (`reference`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `referral_code` (`referral_code`);

--
-- Indexes for table `wallets`
--
ALTER TABLE `wallets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `withdrawals`
--
ALTER TABLE `withdrawals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activity_logs`
--
ALTER TABLE `activity_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `faqs`
--
ALTER TABLE `faqs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `policies`
--
ALTER TABLE `policies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `pos_requests`
--
ALTER TABLE `pos_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `referrals`
--
ALTER TABLE `referrals`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=90;

--
-- AUTO_INCREMENT for table `shares`
--
ALTER TABLE `shares`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `wallets`
--
ALTER TABLE `wallets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `withdrawals`
--
ALTER TABLE `withdrawals`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `activity_logs`
--
ALTER TABLE `activity_logs`
  ADD CONSTRAINT `activity_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `referrals`
--
ALTER TABLE `referrals`
  ADD CONSTRAINT `referrals_ibfk_1` FOREIGN KEY (`referrer_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `referrals_ibfk_2` FOREIGN KEY (`referred_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `shares`
--
ALTER TABLE `shares`
  ADD CONSTRAINT `shares_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `transactions`
--
ALTER TABLE `transactions`
  ADD CONSTRAINT `transactions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `wallets`
--
ALTER TABLE `wallets`
  ADD CONSTRAINT `wallets_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `withdrawals`
--
ALTER TABLE `withdrawals`
  ADD CONSTRAINT `withdrawals_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

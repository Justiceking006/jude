<?php
session_start();
require_once '../connection.php';

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit;
}

// Handle manual credit/debit
$message = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['user_id'], $_POST['amount'], $_POST['type'])) {
    $user_id = intval($_POST['user_id']);
    $amount = floatval($_POST['amount']);
    $type = $_POST['type'];
    $desc = trim($_POST['description'] ?? '');
    if ($amount <= 0) {
        $message = "<span class='text-red-500'>Amount must be positive.</span>";
    } else {
        $stmt = $pdo->prepare("SELECT * FROM wallets WHERE user_id = ?");
        $stmt->execute([$user_id]);
        $wallet = $stmt->fetch();
        if (!$wallet) {
            $pdo->prepare("INSERT INTO wallets (user_id, balance) VALUES (?, ?)")->execute([$user_id, 0]);
            $wallet = ['balance' => 0];
        }
        $new_balance = $type === 'credit' ? $wallet['balance'] + $amount : $wallet['balance'] - $amount;
        if ($new_balance < 0) {
            $message = "<span class='text-red-500'>Insufficient balance for debit.</span>";
        } else {
            $pdo->prepare("UPDATE wallets SET balance = ? WHERE user_id = ?")->execute([$new_balance, $user_id]);
            $pdo->prepare("INSERT INTO activity_logs (user_id, action, description) VALUES (?, ?, ?)")->execute([
                $user_id,
                $type === 'credit' ? 'Admin Credit' : 'Admin Debit',
                $desc ?: ($type === 'credit' ? 'Manual credit by admin' : 'Manual debit by admin')
            ]);
            $message = "<span class='text-green-500'>Wallet updated successfully.</span>";
        }
    }
}

// Filter/search
$where = "";
$params = [];
if (!empty($_GET['user'])) {
    $where .= " AND w.user_id = ?";
    $params[] = $_GET['user'];
}
$sql = "SELECT w.*, u.email FROM wallets w LEFT JOIN users u ON w.user_id = u.id WHERE 1 $where ORDER BY w.balance DESC LIMIT 100";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$wallets = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Admin Wallets/Funds</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-black text-white min-h-screen pb-24">
  <div class="bg-black text-yellow-400 px-4 py-3 flex justify-between items-center sticky top-0 z-50">
    <h1 class="text-xl font-bold">Wallets / Funds</h1>
    <a href="admin_dashboard.php" class="text-yellow-400 hover:underline">Dashboard</a>
  </div>

  <div class="p-4">
    <form method="get" class="flex flex-wrap gap-2 mb-4">
      <input type="text" name="user" placeholder="User ID" value="<?= htmlspecialchars($_GET['user'] ?? '') ?>" class="px-2 py-1 rounded text-black" />
      <button type="submit" class="bg-yellow-500 text-black px-4 py-1 rounded">Filter</button>
    </form>

    <div class="mb-6 bg-gray-900 rounded-lg p-4 max-w-xl mx-auto">
      <h2 class="text-lg font-semibold mb-2">Manual Credit/Debit</h2>
      <?php if ($message): ?>
        <div class="mb-2"><?= $message ?></div>
      <?php endif; ?>
      <form method="post" class="space-y-2">
        <input type="number" name="user_id" placeholder="User ID" required class="w-full px-3 py-2 rounded text-black" />
        <input type="number" step="0.01" name="amount" placeholder="Amount" required class="w-full px-3 py-2 rounded text-black" />
        <select name="type" class="w-full px-3 py-2 rounded text-black" required>
          <option value="credit">Credit</option>
          <option value="debit">Debit</option>
        </select>
        <input type="text" name="description" placeholder="Description (optional)" class="w-full px-3 py-2 rounded text-black" />
        <button type="submit" class="bg-yellow-500 text-black px-4 py-2 rounded w-full font-semibold">Submit</button>
      </form>
    </div>

    <div class="overflow-x-auto">
      <table class="min-w-full text-xs md:text-sm">
        <thead class="bg-yellow-500 text-black">
          <tr>
            <th class="p-2">User ID</th>
            <th class="p-2">Email</th>
            <th class="p-2">Balance</th>
            <th class="p-2">Account #</th>
            <th class="p-2">Bank</th>
            <th class="p-2">Reference</th>
            <th class="p-2">Updated</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($wallets as $w): ?>
            <tr class="border-b border-gray-700">
              <td class="p-2">#<?= $w['user_id'] ?></td>
              <td class="p-2 text-xs"><?= htmlspecialchars($w['email']) ?></td>
              <td class="p-2">₦<?= number_format($w['balance'],2) ?></td>
              <td class="p-2 text-xs"><?= htmlspecialchars($w['account_number']) ?></td>
              <td class="p-2 text-xs"><?= htmlspecialchars($w['bank_name']) ?></td>
              <td class="p-2 text-xs"><?= htmlspecialchars($w['account_reference']) ?></td>
              <td class="p-2 text-xs"><?= date('d M Y H:i', strtotime($w['updated_at'])) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
      <?php if (empty($wallets)): ?>
        <div class="text-center text-gray-400 py-8">No wallets found.</div>
      <?php endif; ?>
    </div>
  </div>

  <footer class="fixed bottom-0 left-0 right-0 bg-black border-t border-gray-800 z-50">
    <div class="flex justify-around py-2 text-xs text-white">
      <a href="admin_dashboard.php" class="flex flex-col items-center hover:text-yellow-400">
        <span>🏠</span>
        <span>Home</span>
      </a>
      <a href="admin_services.php" class="flex flex-col items-center hover:text-yellow-400">
        <span>💸</span>
        <span>Prices</span>
      </a>
      <a href="admin_users.php" class="flex flex-col items-center hover:text-yellow-400">
        <span>👥</span>
        <span>Users</span>
      </a>
      <a href="admin_transactions.php" class="flex flex-col items-center hover:text-yellow-400">
        <span>📄</span>
        <span>Transactions</span>
      </a>
      <a href="admin_withdrawals.php" class="flex flex-col items-center hover:text-yellow-400">
        <span>💵</span>
        <span>Withdrawals</span>
      </a>
      <a href="admin_notifications.php" class="flex flex-col items-center hover:text-yellow-400">
        <span>🔔</span>
        <span>Notifications</span>
      </a>
      <a href="admin_pos_requests.php" class="flex flex-col items-center hover:text-yellow-400">
        <span>🖨️</span>
        <span>POS Requests</span>
      </a>
      <a href="admin_activity_logs.php" class="flex flex-col items-center hover:text-yellow-400">
        <span>📋</span>
        <span>Activity Logs</span>
      </a>
      <a href="admin_profile.php" class="flex flex-col items-center hover:text-yellow-400">
        <span>⚙️</span>
        <span>Profile</span>
      </a>
      <a href="admin_wallets.php" class="flex flex-col items-center text-yellow-400">
        <span>💳</span>
        <span>Wallets</span>
      </a>
      <a href="logout.php" class="flex flex-col items-center text-red-500 hover:text-yellow-500">
        <span>🚪</span>
        <span>Logout</span>
      </a>
    </div>
  </footer>
</body>
</html>

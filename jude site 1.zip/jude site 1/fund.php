<?php
session_start();
require_once 'connection.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// ✅ Fetch user email from DB
$stmt = $pdo->prepare("SELECT email FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$row = $stmt->fetch();
$email = $row['email'] ?? 'invalid@example.com';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Fund Wallet | Son of Grace Exchange</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://js.paystack.co/v1/inline.js"></script>
  <script src="https://unpkg.com/feather-icons"></script>
  <script>
    tailwind.config = {
      theme: {
        extend: {
          colors: {
            gold: '#FFD700',
            black: '#000000',
            white: '#ffffff',
          },
          fontFamily: {
            spaghetti: ['"Pacifico"', 'cursive'],
            body: ['Inter', 'sans-serif'],
          },
        },
      },
    };
  </script>
</head>
<body class="bg-black text-white font-body">

  <!-- ✅ Header -->
  <header class="flex items-center justify-between p-4 border-b border-gold">
    <h1 class="text-xl font-spaghetti text-gold">Son of Grace Exchange</h1>
    <a href="dashboard.php" class="text-gold text-sm">Back</a>
  </header>

  <!-- ✅ Main Content -->
  <main class="p-4 space-y-6 pb-32">
    <!-- 💳 Funding Form -->
    <section>
      <h2 class="text-lg font-bold text-gold mb-2">💳 Fund Your Wallet</h2>
      <form id="fundForm" class="space-y-3">
        <input type="number" id="amount" class="w-full p-2 rounded bg-white text-black" placeholder="Enter Amount (₦)" required min="100" />
        <button type="submit" class="w-full bg-gold text-black py-2 px-4 rounded font-semibold hover:bg-yellow-500 transition">
          Pay with Paystack
        </button>
      </form>
    </section>

    <!-- 📊 History Shortcut -->
    <section>
      <h3 class="text-gold text-md font-semibold mb-1">🕒 Quick Actions</h3>
      <div class="grid grid-cols-2 gap-4">
        <a href="history.php" class="bg-gold text-black text-center py-3 rounded-xl font-semibold hover:bg-yellow-500 transition">
          View Transaction History
        </a>
        <a href="notifications.php" class="bg-gold text-black text-center py-3 rounded-xl font-semibold hover:bg-yellow-500 transition">
          Check Notifications
        </a>
      </div>
    </section>

    <!-- 💡 Funding Tips -->
    <section>
      <h3 class="text-gold text-md font-semibold mb-1">💡 Tips</h3>
      <ul class="list-disc list-inside text-sm text-gray-300 space-y-1">
        <li>Minimum amount is ₦100</li>
        <li>Ensure you're using a valid card</li>
        <li>Successful funding updates wallet automatically</li>
        <li>If delayed, check "History" or contact support</li>
      </ul>
    </section>
  </main>

  <!-- ✅ Bottom Navigation -->
  <nav class="fixed bottom-0 left-0 right-0 bg-black border-t border-gold flex justify-around items-center h-16 p-2 z-50">
    <a href="dashboard.php" class="flex flex-col items-center text-white"><i data-feather="home"></i><span class="text-xs">Home</span></a>
    <a href="dashboard_profile.php" class="flex flex-col items-center"><i data-feather="user"></i><span class="text-xs">Profile</span></a>
    <a href="support.php" class="flex flex-col items-center"><i data-feather="phone"></i><span class="text-xs">Support</span></a>
    <a href="history.php" class="flex flex-col items-center"><i data-feather="clock"></i><span class="text-xs">History</span></a>
    <a href="more.php" class="flex flex-col items-center"><i data-feather="menu"></i><span class="text-xs">More</span></a>
  </nav>

  <!-- ✅ Paystack Logic -->
  <script>
    const form = document.getElementById('fundForm');
    form.addEventListener('submit', function(e) {
      e.preventDefault();
      const amount = document.getElementById('amount').value;
      if (amount < 100) {
        alert("Minimum funding amount is ₦100.");
        return;
      }

      PaystackPop.setup({
        key: 'pk_live_371a5d38a0bea4abe77124dfa46e8bde2e5c6f81', // ✅ Your live public key
        email: <?= json_encode($email) ?>,
        amount: amount * 100,
        currency: "NGN",
        metadata: {
          user_id: <?= json_encode($user_id) ?>
        },
        callback: function(response) {
          alert("✅ Payment completed! Ref: " + response.reference);
          window.location.href = "fund_success.php?ref=" + response.reference;
        },
        onClose: function() {
          alert("⚠️ Payment window closed.");
        }
      }).openIframe();
    });

    feather.replace();
  </script>
</body>
</html>
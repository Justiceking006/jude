<?php
// Enable full error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

session_start();
require_once 'connection.php';

// Check authentication
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// API Configuration
define('API_ENDPOINT', 'https://jossyfeydataservices.com.ng/api/airtime');
define('API_KEY', '9abbqz2dxzibvxldsep51t5m4vznz9ax2iruo6xq');

// Network Pricing Configuration
$NETWORK_PLANS = [
    'MTN' => [
        'serviceID' => '1',
        'plans' => [
            100 => ['user' => 100, 'reseller' => 100, 'api' => 97],
            200 => ['user' => 200, 'reseller' => 200, 'api' => 194],
            500 => ['user' => 500, 'reseller' => 500, 'api' => 485],
            1000 => ['user' => 1000, 'reseller' => 1000, 'api' => 970]
        ]
    ],
    'AIRTEL' => [
        'serviceID' => '2',
        'plans' => [
            100 => ['user' => 100, 'reseller' => 98, 'api' => 97],
            200 => ['user' => 200, 'reseller' => 196, 'api' => 194],
            500 => ['user' => 500, 'reseller' => 490, 'api' => 485]
        ]
    ],
    'GLO' => [
        'serviceID' => '3',
        'plans' => [
            100 => ['user' => 100, 'reseller' => 97, 'api' => 96],
            200 => ['user' => 200, 'reseller' => 194, 'api' => 192],
            500 => ['user' => 500, 'reseller' => 485, 'api' => 480]
        ]
    ],
    '9MOBILE' => [
        'serviceID' => '4',
        'plans' => [
            100 => ['user' => 100, 'reseller' => 98, 'api' => 97],
            200 => ['user' => 200, 'reseller' => 196, 'api' => 194]
        ]
    ]
];

// Initialize variables
$errors = [];
$success = false;
$transaction_data = null;
$calculated_amounts = null;

// Fetch user details with fallback for missing user_type
try {
    $user_id = $_SESSION['user_id'];
    
    // First try to get user_type if column exists
    $stmt = $pdo->prepare("SHOW COLUMNS FROM users LIKE 'user_type'");
    $stmt->execute();
    $column_exists = $stmt->fetch();
    
    if ($column_exists) {
        $stmt = $pdo->prepare("SELECT first_name, phone, user_type FROM users WHERE id = ?");
    } else {
        $stmt = $pdo->prepare("SELECT first_name, phone FROM users WHERE id = ?");
    }
    
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();
    
    // Set default user type if column doesn't exist
    if (!isset($user['user_type'])) {
        $user['user_type'] = 'customer';
    }
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
    $errors['general'] = 'System error. Please try again later.';
}

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && empty($errors)) {
    // Sanitize inputs
    $phone = trim($_POST['phone'] ?? '');
    $network = trim($_POST['network'] ?? '');
    $amount_type = $_POST['amount_type'] ?? 'preset';
    
    // Determine which amount to use
    if ($amount_type === 'custom') {
        $amount = (int)($_POST['custom_amount'] ?? 0);
    } else {
        $amount = (int)($_POST['amount'] ?? 0);
    }
    
    // Validate inputs
    if (empty($phone)) {
        $errors['phone'] = 'Phone number is required';
    } elseif (!preg_match('/^(080|081|090|070|091)\d{8}$/', $phone)) {
        $errors['phone'] = 'Invalid Nigerian phone number';
    }
    
    if (empty($network)) {
        $errors['network'] = 'Network provider is required';
    } elseif (!isset($NETWORK_PLANS[$network])) {
        $errors['network'] = 'Invalid network selected';
    }
    
    if ($amount <= 0) {
        $errors['amount'] = 'Amount must be greater than zero';
    } elseif ($amount_type === 'preset' && !isset($NETWORK_PLANS[$network]['plans'][$amount])) {
        $errors['amount'] = 'Invalid preset amount selected';
    } elseif ($amount_type === 'custom') {
        // Additional validation for custom amounts
        if ($amount % 50 !== 0) {
            $errors['amount'] = 'Amount must be in multiples of 50';
        } elseif ($amount > 10000) {
            $errors['amount'] = 'Maximum amount is ₦10,000';
        }
    }
    
    // If validation passes
    if (empty($errors)) {
        try {
            // Find the appropriate plan (for preset or nearest for custom)
            if ($amount_type === 'preset') {
                $plan = $NETWORK_PLANS[$network]['plans'][$amount];
            } else {
                $nearest_plan = findNearestPlan($amount, $network, $NETWORK_PLANS);
if (!$nearest_plan) {
    throw new Exception("No pricing plan available for this amount");
}
$plan = $nearest_plan['plan'];
// baba Keep original $amount to reflect the actual amount typed by user
                 // Use nearest plan amount for calculation
            }
            
   // Determine which price to use based on user type
$price_key = ($user['user_type'] === 'reseller') ? 'reseller' : 'user';

// Calculate charges differently for custom vs preset
if ($amount_type === 'custom') {
    $user_price = calculateUserCharge($amount, $nearest_plan, $user['user_type']);
    $reseller_charge = $amount * ($plan['reseller'] / $nearest_plan['amount']);
    $api_charge = $amount * ($plan['api'] / $nearest_plan['amount']);
} else {
    $user_price = $plan[$price_key];
    $reseller_charge = $plan['reseller'];
    $api_charge = $plan['api'];
}

// Final breakdown
$calculated_amounts = [
    'face_value' => $amount,
    'user_charge' => $user_price,
    'reseller_charge' => $reseller_charge,
    'api_charge' => $api_charge,
    'profit' => $user_price - $api_charge
];        
            // Prepare API request
            $postData = [
                'serviceID' => $NETWORK_PLANS[$network]['serviceID'],
                'amount' => $amount, // API expects face value
                'mobileNumber' => $phone
            ];
            

/**
 * Finds the nearest plan for custom amounts
 */
function findNearestPlan($amount, $network, $networkPlans) {
    if (!isset($networkPlans[$network])) {
        return null;
    }
    
    $plans = $networkPlans[$network]['plans'];
    $closest = null;
    $smallestDiff = PHP_INT_MAX;
    
    foreach ($plans as $planAmount => $plan) {
        $diff = abs($amount - $planAmount);
        if ($diff < $smallestDiff) {
            $smallestDiff = $diff;
            $closest = [
                'network' => $network,
                'amount' => $planAmount,
                'plan' => $plan
            ];
        }
    }
    
    return $closest;
}

/**
 * Calculates user charge based on amount and user type
 */
function calculateUserCharge($amount, $nearestPlan, $userType) {
    if (!$nearestPlan) {
        return $amount; // Default to face value if no plan found
    }
    
    $multiplier = $nearestPlan['plan'][$userType === 'reseller' ? 'reseller' : 'user'] / $nearestPlan['amount'];
    return $amount * $multiplier;
}

//Calls the actual airtime API endpoint
 
function callAirtimeAPI($data, $networkPlans) {
    try {
        $ch = curl_init();
        
        curl_setopt_array($ch, [
            CURLOPT_URL => API_ENDPOINT,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode($data),
            CURLOPT_HTTPHEADER => [
                'Authorization: Token ' . API_KEY,
                'Content-Type: application/json',
                'Accept: application/json'
            ],
            CURLOPT_TIMEOUT => 30,
            CURLOPT_SSL_VERIFYPEER => true
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        
        if ($error) {
            throw new Exception("CURL Error: " . $error);
        }
        
        $result = json_decode($response, true);
        
        if (!$result) {
            throw new Exception("Invalid API response format");
        }
        
        // Handle different HTTP status codes
        if ($httpCode !== 200) {
            $errorMsg = $result['message'] ?? 'API request failed';
            throw new Exception("API Error ($httpCode): $errorMsg");
        }
        
        // Standardize the response format
        return [
            'status' => 'success',
            'message' => $result['message'] ?? 'Airtime purchase successful',
            'data' => [
                'type' => 'airtime',
                'reference' => $result['data']['reference'] ?? 'TRX-' . uniqid(),
                'amount' => $data['amount'],
                'amountCharged' => $result['data']['amountCharged'] ?? $data['amount'],
                'phoneNumber' => $data['mobileNumber'],
                'network' => array_search($data['serviceID'], array_column($networkPlans, 'serviceID')),
                'status' => $result['data']['status'] ?? 'success'
            ]
        ];
        
    } catch (Exception $e) {
        // Log the error but return a standardized failure response
        error_log("API Call Error: " . $e->getMessage());
        
        return [
            'status' => 'failed',
            'message' => $e->getMessage(),
            'data' => [
                'reference' => 'FAIL-' . uniqid(),
                'status' => 'failed'
            ]
        ];
    }
}

/**
 * Saves transaction with commission details
 */
function saveTransaction($user_id, $transaction_data, $calculated_amounts, $pdo) {
    try {
        // Check if columns exist
        $stmt = $pdo->prepare("SHOW COLUMNS FROM transactions LIKE 'face_value'");
        $stmt->execute();
        $columns_exist = $stmt->fetch();
        
        if ($columns_exist) {
            $sql = "INSERT INTO transactions 
                    (user_id, type, reference, amount, amount_charged, 
                     face_value, user_charge, reseller_charge, api_charge, profit,
                     phone, network, status, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())";
            
            $params = [
                $user_id,
                'airtime',
                $transaction_data['reference'],
                $calculated_amounts['face_value'],
                $calculated_amounts['user_charge'],
                $calculated_amounts['face_value'],
                $calculated_amounts['user_charge'],
                $calculated_amounts['reseller_charge'],
                $calculated_amounts['api_charge'],
                $calculated_amounts['profit'],
                $transaction_data['phoneNumber'],
                $transaction_data['network'],
                $transaction_data['status']
            ];
        } else {
            // Fallback to basic transaction recording
            $sql = "INSERT INTO transactions 
                    (user_id, service, provider, amount, status, reference, phone, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, NOW())";
            
            $params = [
                $user_id,
                'airtime',
                $transaction_data['network'],
                $calculated_amounts['user_charge'],
                $transaction_data['status'],
                $transaction_data['reference'],
                $transaction_data['phoneNumber']
            ];
        }
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        
    } catch (PDOException $e) {
        error_log("Failed to save transaction: " . $e->getMessage());
        throw $e;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Airtime Top-up | Son of Grace Exchange</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/feather-icons"></script>
  <script>
    tailwind.config = {
      theme: {
        extend: {
          colors: {
            gold: '#FFD700',
            black: '#000000',
            white: '#ffffff',
          },
          fontFamily: {
            spaghetti: ['"Pacifico"', 'cursive'],
            body: ['Inter', 'sans-serif'],
          },
        },
      },
    };
  </script>
</head>
<body class="bg-black text-white font-body">
<!-- Hidden element to pass PHP data to JavaScript -->
<div id="network_plans_data" data-plans='<?= json_encode($NETWORK_PLANS) ?>' style="display:none;"></div>

<!-- Header -->
<header class="flex items-center justify-between p-4 border-b border-gold">
  <h1 class="text-xl font-spaghetti text-gold">Son of Grace Exchange</h1>
  <a href="dashboard.php" class="text-gold">Back</a>
</header>

<!-- Main Content -->
<main class="p-4 pb-32 space-y-6">
  <section class="space-y-2">
    <h2 class="text-lg font-semibold text-gold">📱 Airtime Top-up</h2>
    <p class="text-sm text-white">
      Recharge any Nigerian mobile number instantly. Enjoy competitive rates!
    </p>
  </section>

  <?php if ($success): ?>
    <!-- Success Message -->
    <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded">
      <strong class="font-bold">Success!</strong>
      <div class="mt-2">
        <p><strong>Reference:</strong> <?= htmlspecialchars($transaction_data['reference']) ?></p>
        <p><strong>Phone:</strong> <?= htmlspecialchars($transaction_data['phoneNumber']) ?></p>
        <p><strong>Network:</strong> <?= htmlspecialchars($transaction_data['network']) ?></p>
        <p><strong>Face Value:</strong> ₦<?= number_format($calculated_amounts['face_value'], 2) ?></p>
        <p><strong>You Paid:</strong> ₦<?= number_format($calculated_amounts['user_charge'], 2) ?></p>
      </div>
    </div>
    <a href="airtime.php" class="w-full bg-gold text-black py-2 px-4 rounded font-semibold hover:bg-yellow-500 transition text-center block">
      Buy Again
    </a>
  <?php else: ?>
    <!-- Airtime Form -->
    <form method="POST" class="space-y-4">
      <?php if (!empty($errors['general'])): ?>
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
          <?= htmlspecialchars($errors['general']) ?>
        </div>
      <?php endif; ?>
      
      <div>
        <label for="phone" class="block text-sm font-medium text-gold mb-1">Phone Number</label>
        <input type="tel" id="phone" name="phone" 
               value="<?= htmlspecialchars($_POST['phone'] ?? $user['phone'] ?? '') ?>"
               class="w-full p-2 rounded bg-white text-black <?= !empty($errors['phone']) ? 'border-red-500' : '' ?>"
               placeholder="08012345678" required>
        <?php if (!empty($errors['phone'])): ?>
          <p class="text-red-500 text-xs mt-1"><?= htmlspecialchars($errors['phone']) ?></p>
        <?php endif; ?>
      </div>
      
      <div>
        <label for="network" class="block text-sm font-medium text-gold mb-1">Network Provider</label>
        <select id="network" name="network" class="w-full p-2 rounded bg-white text-black" required>
          <option value="">Select Network</option>
          <?php foreach ($NETWORK_PLANS as $net => $data): ?>
            <option value="<?= $net ?>" <?= ($_POST['network'] ?? '') === $net ? 'selected' : '' ?>>
              <?= $net ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>
      
      <div class="grid grid-cols-2 gap-4">
        <div>
          <label for="amount_type" class="block text-sm font-medium text-gold mb-1">Amount Type</label>
          <select id="amount_type" name="amount_type" class="w-full p-2 rounded bg-white text-black" disabled>
            <option value="preset" <?= ($_POST['amount_type'] ?? 'preset') === 'preset' ? 'selected' : '' ?>>Select from list</option>
            <option value="custom" <?= ($_POST['amount_type'] ?? '') === 'custom' ? 'selected' : '' ?>>Enter custom amount</option>
          </select>
        </div>
        
        <div id="preset_amount_container">
          <label for="amount" class="block text-sm font-medium text-gold mb-1">Amount (₦)</label>
          <select id="amount" name="amount" class="w-full p-2 rounded bg-white text-black">
            <option value="">Select Amount</option>
            <?php if (isset($_POST['network']) && isset($NETWORK_PLANS[$_POST['network']])): ?>
              <?php foreach ($NETWORK_PLANS[$_POST['network']]['plans'] as $amt => $plan): ?>
                <option value="<?= $amt ?>" <?= ($_POST['amount'] ?? 0) == $amt ? 'selected' : '' ?>>
                  ₦<?= number_format($amt) ?> (You pay: ₦<?= number_format($plan['user'], 2) ?>)
                </option>
              <?php endforeach; ?>
            <?php endif; ?>
          </select>
        </div>
        
        <div id="custom_amount_container" class="hidden col-span-2">
          <label for="custom_amount" class="block text-sm font-medium text-gold mb-1">Custom Amount (₦)</label>
          <input type="number" id="custom_amount" name="custom_amount" 
                 value="<?= htmlspecialchars($_POST['custom_amount'] ?? '') ?>"
                 class="w-full p-2 rounded bg-white text-black"
                 placeholder="Enter amount in multiples of 50" min="50" step="50">
        </div>
      </div>
      
      <?php if (!empty($errors['amount'])): ?>
        <p class="text-red-500 text-xs"><?= htmlspecialchars($errors['amount']) ?></p>
      <?php endif; ?>
      
      <!-- Dynamic Pricing Preview -->
      <?php if (isset($_POST['network']) && (isset($_POST['amount']) || isset($_POST['custom_amount'])) && empty($errors)): ?>
        <?php
        $amount = $_POST['amount_type'] === 'custom' ? (int)$_POST['custom_amount'] : (int)$_POST['amount'];
        $nearest_plan = findNearestPlan($amount, $_POST['network'], $NETWORK_PLANS);
        ?>
        <div class="bg-gray-800 p-3 rounded">
          <h3 class="text-gold font-semibold">Pricing Breakdown</h3>
          <p>Face Value: ₦<?= number_format($amount, 2) ?></p>
          <p>You Pay: ₦<?= number_format(calculateUserCharge($amount, $nearest_plan, $user['user_type']), 2) ?></p>
          <?php if ($_POST['amount_type'] === 'custom'): ?>
            <p class="text-xs text-gray-400">Based on <?= $nearest_plan['network'] ?> ₦<?= $nearest_plan['amount'] ?> plan rates</p>
          <?php endif; ?>
        </div>
      <?php endif; ?>
      
      <button type="submit" class="w-full bg-gold text-black py-2 px-4 rounded font-semibold hover:bg-yellow-500 transition">
        Proceed to Payment
      </button>
    </form>
  <?php endif; ?>
</main>

<!-- Bottom Navigation -->
<nav class="fixed bottom-0 left-0 right-0 bg-black border-t border-gold flex justify-around items-center p-2 z-50">
  <a href="dashboard.php" class="flex flex-col items-center"><i data-feather="home"></i><span class="text-xs">Home</span></a>
  <a href="dashboard_profile.php" class="flex flex-col items-center"><i data-feather="user"></i><span class="text-xs">Profile</span></a>
  <a href="support.php" class="flex flex-col items-center"><i data-feather="phone"></i><span class="text-xs">Support</span></a>
  <a href="history.php" class="flex flex-col items-center"><i data-feather="clock"></i><span class="text-xs">History</span></a>
  <a href="more.php" class="flex flex-col items-center"><i data-feather="menu"></i><span class="text-xs">More</span></a>
</nav>

<script>
  // Initialize feather icons
  feather.replace();

  // Get network plans from PHP
  const networkPlans = JSON.parse(document.getElementById('network_plans_data').dataset.plans);

  // Dynamic amount dropdown based on network selection
  document.getElementById('network').addEventListener('change', function() {
    const network = this.value;
    const amountSelect = document.getElementById('amount');
    const amountTypeSelect = document.getElementById('amount_type');
    
    // Reset amount fields
    amountSelect.innerHTML = '<option value="">Select Amount</option>';
    document.getElementById('custom_amount').value = '';
    
    // Enable amount type selection when network is chosen
    amountTypeSelect.disabled = !network;
    
    if (network && networkPlans[network]) {
        // Populate preset amounts
        Object.keys(networkPlans[network].plans).forEach(amt => {
            const plan = networkPlans[network].plans[amt];
            const option = document.createElement('option');
            option.value = amt;
            option.textContent = `₦${parseInt(amt).toLocaleString()} (You pay: ₦${plan.user.toLocaleString()})`;
            amountSelect.appendChild(option);
        });
        
        // Reset to preset amount view
        amountTypeSelect.value = 'preset';
        document.getElementById('preset_amount_container').classList.remove('hidden');
        document.getElementById('custom_amount_container').classList.add('hidden');
    }
  });

  // Toggle between preset and custom amount
  document.getElementById('amount_type').addEventListener('change', function() {
    const type = this.value;
    document.getElementById('preset_amount_container').classList.toggle('hidden', type === 'custom');
    document.getElementById('custom_amount_container').classList.toggle('hidden', type !== 'custom');
    
    // Clear the inactive field
    if (type === 'custom') {
        document.getElementById('amount').value = '';
        document.getElementById('custom_amount').focus();
    } else {
        document.getElementById('custom_amount').value = '';
    }
  });

  // Client-side form validation
  document.querySelector('form').addEventListener('submit', function(e) {
    const network = document.getElementById('network').value;
    const amountType = document.getElementById('amount_type').value;
    const amount = amountType === 'custom' 
        ? document.getElementById('custom_amount').value 
        : document.getElementById('amount').value;
    
    if (!network) {
        alert('Please select a network provider');
        e.preventDefault();
        return;
    }
    
    if (!amount || isNaN(amount) || parseInt(amount) <= 0) {
        alert('Please enter a valid amount greater than zero');
        e.preventDefault();
        return;
    }
    
    if (amountType === 'custom' && parseInt(amount) % 50 !== 0) {
        alert('Custom amounts must be in multiples of ₦50');
        e.preventDefault();
        return;
    }
  });
</script>
</body>
</html>
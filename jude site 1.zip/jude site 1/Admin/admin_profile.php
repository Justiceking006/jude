<?php
session_start();
require_once '../connection.php';

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit;
}

// Handle password change
$message = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $current = $_POST['current_password'] ?? '';
    $new = $_POST['new_password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';
    $admin_id = $_SESSION['admin_id'];

    $stmt = $pdo->prepare("SELECT password FROM admins WHERE id = ?");
    $stmt->execute([$admin_id]);
    $admin = $stmt->fetch();

    if (!$admin || !password_verify($current, $admin['password'])) {
        $message = "<span class='text-red-500'>Current password is incorrect.</span>";
    } elseif (strlen($new) < 6) {
        $message = "<span class='text-red-500'>New password must be at least 6 characters.</span>";
    } elseif ($new !== $confirm) {
        $message = "<span class='text-red-500'>Passwords do not match.</span>";
    } else {
        $hash = password_hash($new, PASSWORD_DEFAULT);
        $pdo->prepare("UPDATE admins SET password = ? WHERE id = ?")->execute([$hash, $admin_id]);
        $message = "<span class='text-green-500'>Password updated successfully.</span>";
    }
}

// Get admin info
$stmt = $pdo->prepare("SELECT * FROM admins WHERE id = ?");
$stmt->execute([$_SESSION['admin_id']]);
$admin = $stmt->fetch();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Admin Profile/Settings</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-black text-white min-h-screen pb-24">
  <div class="bg-black text-yellow-400 px-4 py-3 flex justify-between items-center sticky top-0 z-50">
    <h1 class="text-xl font-bold">Admin Profile/Settings</h1>
    <a href="admin_dashboard.php" class="text-yellow-400 hover:underline">Dashboard</a>
  </div>

  <div class="p-4 max-w-lg mx-auto">
    <div class="mb-6 bg-gray-900 rounded-lg p-4">
      <h2 class="text-lg font-semibold mb-2">Profile Info</h2>
      <div><span class="text-gray-400">Name:</span> <?= htmlspecialchars($admin['name']) ?></div>
      <div><span class="text-gray-400">Email:</span> <?= htmlspecialchars($admin['email']) ?></div>
      <div><span class="text-gray-400">Phone:</span> <?= htmlspecialchars($admin['phone']) ?></div>
      <div><span class="text-gray-400">Created:</span> <?= date('d M Y', strtotime($admin['created_at'])) ?></div>
    </div>

    <div class="bg-gray-900 rounded-lg p-4">
      <h2 class="text-lg font-semibold mb-2">Change Password</h2>
      <?php if ($message): ?>
        <div class="mb-2"><?= $message ?></div>
      <?php endif; ?>
      <form method="post" class="space-y-3">
        <input type="password" name="current_password" placeholder="Current Password" required class="w-full px-3 py-2 rounded text-black" />
        <input type="password" name="new_password" placeholder="New Password" required class="w-full px-3 py-2 rounded text-black" />
        <input type="password" name="confirm_password" placeholder="Confirm New Password" required class="w-full px-3 py-2 rounded text-black" />
        <button type="submit" class="bg-yellow-500 text-black px-4 py-2 rounded w-full font-semibold">Update Password</button>
      </form>
    </div>
  </div>

  <footer class="fixed bottom-0 left-0 right-0 bg-black border-t border-gray-800 z-50">
    <div class="flex justify-around py-2 text-xs text-white">
      <a href="admin_dashboard.php" class="flex flex-col items-center hover:text-yellow-400">
        <span>🏠</span>
        <span>Home</span>
      </a>
      <a href="admin_services.php" class="flex flex-col items-center hover:text-yellow-400">
        <span>💸</span>
        <span>Prices</span>
      </a>
      <a href="admin_users.php" class="flex flex-col items-center hover:text-yellow-400">
        <span>👥</span>
        <span>Users</span>
      </a>
      <a href="admin_transactions.php" class="flex flex-col items-center hover:text-yellow-400">
        <span>📄</span>
        <span>Transactions</span>
      </a>
      <a href="admin_withdrawals.php" class="flex flex-col items-center hover:text-yellow-400">
        <span>💵</span>
        <span>Withdrawals</span>
      </a>
      <a href="admin_notifications.php" class="flex flex-col items-center hover:text-yellow-400">
        <span>🔔</span>
        <span>Notifications</span>
      </a>
      <a href="admin_pos_requests.php" class="flex flex-col items-center hover:text-yellow-400">
        <span>🖨️</span>
        <span>POS Requests</span>
      </a>
      <a href="admin_activity_logs.php" class="flex flex-col items-center hover:text-yellow-400">
        <span>📋</span>
        <span>Activity Logs</span>
      </a>
      <a href="admin_profile.php" class="flex flex-col items-center text-yellow-400">
        <span>⚙️</span>
        <span>Profile</span>
      </a>
      <a href="logout.php" class="flex flex-col items-center text-red-500 hover:text-yellow-500">
        <span>🚪</span>
        <span>Logout</span>
      </a>
    </div>
  </footer>
</body>
</html>

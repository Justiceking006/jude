<?php
session_start();
require_once 'connection.php';

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit;
}

$admin_name = $_SESSION['admin_name'];

$total_users = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$total_balance = $pdo->query("SELECT SUM(balance) FROM wallets")->fetchColumn();
$transactions_today = $pdo->query("SELECT COUNT(*) FROM transactions WHERE DATE(created_at) = CURDATE()")->fetchColumn();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Admin Dashboard</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-black text-white min-h-screen pb-24">

  <!-- Header -->
  <div class="bg-black text-yellow-400 px-4 py-3 flex justify-between items-center sticky top-0 z-50">
    <h1 class="text-xl font-bold">Son of Grace Exchange (Admin)</h1>
    <span class="text-sm">👋 <?= htmlspecialchars($admin_name) ?></span>
  </div>

  <!-- Cards -->
  <div class="p-4 grid grid-cols-1 sm:grid-cols-3 gap-4">
    <div class="bg-yellow-500 text-black rounded-xl p-4 shadow">
      <p class="text-sm">Total Users</p>
      <h2 class="text-xl font-bold"><?= $total_users ?? 0 ?></h2>
    </div>
    <div class="bg-yellow-500 text-black rounded-xl p-4 shadow">
      <p class="text-sm">Wallet Balances</p>
      <h2 class="text-xl font-bold">₦<?= number_format($total_balance ?? 0, 2) ?></h2>
    </div>
    <div class="bg-yellow-500 text-black rounded-xl p-4 shadow">
      <p class="text-sm">Transactions Today</p>
      <h2 class="text-xl font-bold"><?= $transactions_today ?? 0 ?></h2>
    </div>
  </div>

  <!-- Quick Actions -->
  <div class="px-4 mt-6">
    <h2 class="text-lg text-yellow-400 font-semibold mb-3">Quick Actions</h2>
    <div class="grid grid-cols-2 sm:grid-cols-3 gap-4">
      <a href="admin_services.php" class="bg-yellow-500 text-black rounded-lg py-3 text-center font-semibold hover:bg-yellow-600">Edit Prices</a>
      <a href="admin_upload_csv.php" class="bg-yellow-500 text-black rounded-lg py-3 text-center font-semibold hover:bg-yellow-600">Upload CSV</a>
      <a href="admin_transactions.php" class="bg-yellow-500 text-black rounded-lg py-3 text-center font-semibold hover:bg-yellow-600">Transactions</a>
    </div>
  </div>

  <!-- Footer Navigation (Admin) -->
  <footer class="fixed bottom-0 left-0 right-0 bg-black border-t border-gray-800 z-50">
    <div class="flex justify-around py-2 text-xs text-white">
      <a href="admin_dashboard.php" class="flex flex-col items-center text-yellow-400">
        <span>🏠</span>
        <span>Home</span>
      </a>
      <a href="admin_services.php" class="flex flex-col items-center hover:text-yellow-400">
        <span>💸</span>
        <span>Prices</span>
      </a>
      <a href="admin_users.php" class="flex flex-col items-center hover:text-yellow-400">
        <span>👥</span>
        <span>Users</span>
      </a>
      <a href="admin_funds.php" class="flex flex-col items-center hover:text-yellow-400">
        <span>💰</span>
        <span>Funds</span>
      </a>
      <a href="logout.php" class="flex flex-col items-center text-red-500 hover:text-yellow-500">
        <span>🚪</span>
        <span>Logout</span>
      </a>
    </div>
  </footer>

</body>
</html>
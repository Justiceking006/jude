<?php
session_start();
require_once 'connection.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Support | Son of Grace Exchange</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/feather-icons"></script>
  <script>
    tailwind.config = {
      theme: {
        extend: {
          colors: {
            gold: '#FFD700',
            black: '#000000',
            white: '#ffffff',
          },
          fontFamily: {
            spaghetti: ['"Pacifico"', 'cursive'],
            body: ['Inter', 'sans-serif'],
          },
        },
      },
    };
  </script>
  <link href="https://fonts.googleapis.com/css2?family=Pacifico&family=Inter:wght@400;600&display=swap" rel="stylesheet">
</head>
<body class="bg-black text-white font-body">

  <!-- Header -->
  <header class="flex items-center justify-between p-4 border-b border-gold">
    <h1 class="font-spaghetti text-gold text-xl">Son of Grace Exchange</h1>
    <a href="dashboard.php" class="text-gold">Back</a>
  </header>

  <!-- Support Content -->
  <main class="px-4 py-4 space-y-4">
    <h2 class="text-lg font-semibold text-gold">Support & Contact</h2>

    <!-- WhatsApp Support -->
    <section class="bg-white text-black rounded-lg p-3 flex items-center space-x-3 hover:bg-gold hover:text-black transition">
      <i data-feather="message-circle" class="text-gold"></i>
      <div>
        <p class="font-medium">WhatsApp Support</p>
        <a href="https://wa.me/2348108255139" class="text-sm text-blue-600">+234 810 825 5139</a>
      </div>
    </section>

    <!-- Email Support -->
    <section class="bg-white text-black rounded-lg p-3 flex items-center space-x-3 hover:bg-gold hover:text-black transition">
      <i data-feather="mail" class="text-gold"></i>
      <div>
        <p class="font-medium">Email Support</p>
        <a href="mailto:ezejudeuzoma02@gmail.com" class="text-sm text-blue-600">ezejudeuzoma02@gmail.com</a>
      </div>
    </section>

    <!-- Developer Contact 
    <section class="bg-white text-black rounded-lg p-3 flex items-center space-x-3 hover:bg-gold hover:text-black transition">
      <i data-feather="tool" class="text-gold"></i>
      <div>
        <p class="font-medium">Developer Contact</p>
        <a href="https://wa.me/2348161431114" class="text-sm text-blue-600">+234 816 143 1114 (WhatsApp only)</a>
        <p class="text-sm text-gray-600">justiceking006@gmail.com</p>
      </div>
    </section>
    ---->

    <!-- Social Links -->
    <h3 class="text-md font-semibold text-gold pt-2">Follow Us</h3>

    <div class="grid grid-cols-2 gap-3">
      <a href="https://www.facebook.com/profile.php?id=61565248921450" target="_blank" class="bg-white text-black rounded-lg p-3 flex items-center space-x-3 hover:bg-gold hover:text-black transition">
        <i data-feather="facebook" class="text-blue-600"></i><span>Facebook</span>
      </a>
      <a href="https://www.instagram.com/judesonofgrace_exchange/profilecard/?igsh=MTBnN2E5ZWV3djYzeA==" target="_blank" class="bg-white text-black rounded-lg p-3 flex items-center space-x-3 hover:bg-gold hover:text-black transition">
        <i data-feather="camera" class="text-pink-600"></i><span>Instagram</span>
      </a>
      <a href="https://www.tiktok.com/@judesonofgraceexchange?_t=ZM-8xswdYRUL6m&_r=1" target="_blank" class="bg-white text-black rounded-lg p-3 flex items-center space-x-3 hover:bg-gold hover:text-black transition">
        <i data-feather="play" class="text-black"></i><span>TikTok</span>
      </a>
    </div>
  </main>

  <!-- Footer -->
  <nav class="fixed bottom-0 left-0 right-0 bg-black border-t border-gold flex justify-around items-center p-2 z-50">
    <a href="dashboard.php" class="nav-item flex flex-col items-center text-gold">
      <i data-feather="home"></i>
      <span class="text-xs">Home</span>
    </a>
    <a href="dashboard_profile.php" class="nav-item flex flex-col items-center text-gold">
      <i data-feather="user"></i>
      <span class="text-xs">Profile</span>
    </a>
    <a href="support.php" class="nav-item flex flex-col items-center text-white font-bold">
      <i data-feather="phone"></i>
      <span class="text-xs">Support</span>
    </a>
    <a href="history.php" class="nav-item flex flex-col items-center text-gold">
      <i data-feather="clock"></i>
      <span class="text-xs">History</span>
    </a>
    <a href="more.php" class="nav-item flex flex-col items-center text-gold">
      <i data-feather="menu"></i>
      <span class="text-xs">More</span>
    </a>
  </nav>

  <script>feather.replace();</script>
</body>
</html>
<!DOCTYPE html>
<html lang="en" class="bg-black text-white font-body">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Register | Son of Grace Exchange</title>

  <!-- Tailwind CSS -->
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    tailwind.config = {
      theme: {
        extend: {
          colors: {
            gold: '#FFD700',
            black: '#000000',
            white: '#ffffff',
          },
          fontFamily: {
            spaghetti: ['"Pacifico"', 'cursive'],
            body: ['Inter', 'sans-serif'],
          },
        },
      },
    };
  </script>
  <link href="https://fonts.googleapis.com/css2?family=Pacifico&family=Inter:wght@400;600&display=swap" rel="stylesheet">
  <script src="https://unpkg.com/feather-icons"></script>
</head>
<body class="bg-black text-white font-body">

  <!-- REGISTER FORM -->
  <main class="flex items-center justify-center min-h-screen px-4">
    <div class="w-full max-w-md bg-black p-8 rounded-lg border border-gold shadow-md">
      <h2 class="text-2xl font-bold text-gold text-center mb-6">Create an Account</h2>

      <?php if (isset($_GET['error'])): ?>
        <div class="bg-red-600 text-white text-sm px-4 py-2 rounded mb-4 text-center">
          <?= htmlspecialchars($_GET['error']) ?>
        </div>
      <?php endif; ?>

      <form id="registerForm" action="register_script.php" method="POST" class="space-y-4">
        <?php if (isset($_GET['ref'])): ?>
          <input type="hidden" name="referral" value="<?= htmlspecialchars($_GET['ref']) ?>">
        <?php endif; ?>

        <div>
          <label for="firstName" class="block text-sm mb-1">Full Name</label>
          <input type="text" id="firstName" name="first_name" class="w-full px-3 py-2 bg-transparent border-b border-gold text-white focus:outline-none" required />
        </div>

        <div>
          <label for="mobile" class="block text-sm mb-1">Mobile Number</label>
          <input type="tel" id="mobile" name="mobile" class="w-full px-3 py-2 bg-transparent border-b border-gold text-white focus:outline-none" required />
        </div>

        <div>
          <label for="email" class="block text-sm mb-1">Email Address</label>
          <input type="email" id="email" name="email" class="w-full px-3 py-2 bg-transparent border-b border-gold text-white focus:outline-none" required />
        </div>

        <div class="relative">
          <label for="password" class="block text-sm mb-1">Password</label>
          <input type="password" id="password" name="password" class="w-full px-3 py-2 bg-transparent border-b border-gold text-white pr-10 focus:outline-none" required />
          <button type="button" class="absolute top-7 right-2 text-gold toggle-password" data-target="password">
            <i data-feather="eye"></i>
          </button>
        </div>

        <div class="relative">
          <label for="confirmPassword" class="block text-sm mb-1">Confirm Password</label>
          <input type="password" id="confirmPassword" name="confirm_password" class="w-full px-3 py-2 bg-transparent border-b border-gold text-white pr-10 focus:outline-none" required />
          <button type="button" class="absolute top-7 right-2 text-gold toggle-password" data-target="confirmPassword">
            <i data-feather="eye"></i>
          </button>
        </div>

        <button type="submit" class="w-full bg-gold text-black py-2 font-bold rounded hover:bg-yellow-400 transition">
          Register
        </button>
      </form>

      <p class="mt-4 text-sm text-center">
        Already have an account?
        <a href="login.html" class="underline text-white hover:text-gold transition">Login</a>
      </p>
    </div>
  </main>

  <script>
    feather.replace();
    document.querySelectorAll('.toggle-password').forEach(button => {
      button.addEventListener('click', () => {
        const input = document.getElementById(button.dataset.target);
        input.type = input.type === 'password' ? 'text' : 'password';
        button.innerHTML = input.type === 'text'
          ? feather.icons["eye-off"].toSvg()
          : feather.icons["eye"].toSvg();
      });
    });
  </script>
</body>
</html>
<?php
session_start();
require_once 'connection.php';

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit;
}

$admin_name = $_SESSION['admin_name'];

// Fetch all users with their wallet balance
$stmt = $pdo->query("
    SELECT u.id, u.name, u.email, u.phone, u.created_at, w.balance
    FROM users u
    LEFT JOIN wallets w ON u.id = w.user_id
    ORDER BY u.created_at DESC
");
$users = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Manage Users</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 text-gray-900">

  <!-- Top bar -->
  <div class="bg-black text-white p-4 flex justify-between items-center">
    <h1 class="text-lg font-bold text-yellow-400">Son of Grace Admin</h1>
    <a href="logout.php" class="text-red-500 hover:text-red-300">Logout</a>
  </div>

  <main class="p-6">
    <h2 class="text-2xl font-bold mb-4">👥 All Users</h2>

    <div class="overflow-x-auto">
      <table class="w-full bg-white shadow rounded-lg text-sm">
        <thead class="bg-gray-800 text-white">
          <tr>
            <th class="p-3">Name</th>
            <th class="p-3">Email</th>
            <th class="p-3">Phone</th>
            <th class="p-3">Balance</th>
            <th class="p-3">Registered</th>
            <th class="p-3">Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($users as $user): ?>
            <tr class="border-b hover:bg-gray-100">
              <td class="p-3"><?= htmlspecialchars($user['name']) ?></td>
              <td class="p-3"><?= htmlspecialchars($user['email']) ?></td>
              <td class="p-3"><?= htmlspecialchars($user['phone']) ?></td>
              <td class="p-3">₦<?= number_format($user['balance'] ?? 0, 2) ?></td>
              <td class="p-3"><?= date("d M, Y", strtotime($user['created_at'])) ?></td>
              <td class="p-3 space-x-2">
                <a href="admin_user_details.php?id=<?= $user['id'] ?>" class="text-blue-500 hover:underline">View</a>
                <a href="admin_suspend_user.php?id=<?= $user['id'] ?>" class="text-red-500 hover:underline">Suspend</a>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </main>

  <!-- Admin bottom nav -->
  <footer class="fixed bottom-0 w-full bg-black text-yellow-400 flex justify-around text-xs py-2 border-t border-yellow-700 md:hidden">
    <a href="admin_dashboard.php" class="text-center">
      <div>🏠</div><div>Home</div>
    </a>
    <a href="admin_users.php" class="text-center">
      <div>👥</div><div>Users</div>
    </a>
    <a href="admin_services.php" class="text-center">
      <div>💰</div><div>Prices</div>
    </a>
    <a href="admin_funds.php" class="text-center">
      <div>💵</div><div>Funds</div>
    </a>
    <a href="admin_settings.php" class="text-center">
      <div>⚙️</div><div>Settings</div>
    </a>
  </footer>

</body>
</html>
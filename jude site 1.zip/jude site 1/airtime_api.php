<?php
session_start();
header('Content-Type: application/json');

require_once 'connection.php'; // Ensure this points to your DB config

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$user_id = $_SESSION['user_id'];

// 📥 Get JSON input
$input = json_decode(file_get_contents('php://input'), true);
$network = intval($input['network'] ?? 0);
$mobile_number = trim($input['mobile_number'] ?? '');
$amount = floatval($input['amount'] ?? 0);

// ✅ Validation
if ($network < 1 || $network > 4 || strlen($mobile_number) < 10 || $amount < 50) {
    echo json_encode(['success' => false, 'message' => 'Invalid input.']);
    exit;
}

// 💳 Check wallet balance
$stmt = $pdo->prepare("SELECT wallet_balance FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if (!$user) {
    echo json_encode(['success' => false, 'message' => 'User not found.']);
    exit;
}

$current_balance = floatval($user['wallet_balance']);

if ($current_balance < $amount) {
    echo json_encode(['success' => false, 'message' => 'Insufficient balance.']);
    exit;
}

// 🧾 Begin transaction
try {
    $pdo->beginTransaction();

    // 💸 Deduct from wallet
    $stmt = $pdo->prepare("UPDATE users SET wallet_balance = wallet_balance - ? WHERE id = ?");
    $stmt->execute([$amount, $user_id]);

    // 🗃️ Log transaction
    $stmt = $pdo->prepare("INSERT INTO transactions (user_id, type, amount, description, status, created_at)
                           VALUES (?, 'airtime', ?, ?, 'pending', NOW())");
    $stmt->execute([$user_id, $amount, "Airtime to $mobile_number"]);

    $transaction_id = $pdo->lastInsertId();

    // 📡 TODO: Integrate Gladtidings API here
    // For now, just simulate success after 1s delay
    sleep(1);

    // ✅ Update transaction to successful
    $stmt = $pdo->prepare("UPDATE transactions SET status = 'success' WHERE id = ?");
    $stmt->execute([$transaction_id]);

    $pdo->commit();

    echo json_encode(['success' => true, 'message' => 'Airtime sent successfully.']);

} catch (Exception $e) {
    $pdo->rollBack();
    echo json_encode(['success' => false, 'message' => 'Transaction failed.']);
}
?>
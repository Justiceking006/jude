<?php
require_once("connection.php");

$filename = "services.csv";
if (!file_exists($filename)) {
  die("CSV file not found!");
}

$file = fopen($filename, "r");
fgetcsv($file); // Skip header

$success = 0;
$fail = 0;

while (($row = fgetcsv($file)) !== FALSE) {
  $category = $conn->real_escape_string($row[0]);
  $network = $conn->real_escape_string($row[1]);
  $plan_name = $conn->real_escape_string($row[2]);
  $type = $conn->real_escape_string($row[3]);
  $service_id = $conn->real_escape_string($row[4]);
  $user_price = floatval($row[5]);
  $reseller_price = floatval($row[6]);
  $api_user_price = floatval($row[7]);
  $validity = $conn->real_escape_string($row[8]);
  $unit_type = $conn->real_escape_string($row[9]);
  $status = $conn->real_escape_string($row[10]);

  $sql = "INSERT INTO services 
    (category, network, plan_name, type, service_id, user_price, reseller_price, api_user_price, validity, unit_type, status) 
    VALUES 
    ('$category', '$network', '$plan_name', '$type', '$service_id', $user_price, $reseller_price, $api_user_price, '$validity', '$unit_type', '$status')";

  if ($conn->query($sql)) {
    $success++;
  } else {
    $fail++;
  }
}

fclose($file);
$conn->close();

echo "✅ Imported: $success rows\n❌ Failed: $fail rows\n";
?>
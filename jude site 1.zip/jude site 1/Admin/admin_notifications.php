<?php
session_start();
require_once '../connection.php';

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit;
}

// Filter/search
$where = "";
$params = [];
if (!empty($_GET['user'])) {
    $where .= " AND n.user_id = ?";
    $params[] = $_GET['user'];
}
if (!empty($_GET['is_read'])) {
    $where .= " AND n.is_read = ?";
    $params[] = $_GET['is_read'];
}

$sql = "SELECT n.*, u.email FROM notifications n LEFT JOIN users u ON n.user_id = u.id WHERE 1 $where ORDER BY n.created_at DESC LIMIT 100";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$notifications = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Admin Notifications</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-black text-white min-h-screen pb-24">
  <div class="bg-black text-yellow-400 px-4 py-3 flex justify-between items-center sticky top-0 z-50">
    <h1 class="text-xl font-bold">Notifications</h1>
    <a href="admin_dashboard.php" class="text-yellow-400 hover:underline">Dashboard</a>
  </div>

  <div class="p-4">
    <form method="get" class="flex flex-wrap gap-2 mb-4">
      <input type="text" name="user" placeholder="User ID" value="<?= htmlspecialchars($_GET['user'] ?? '') ?>" class="px-2 py-1 rounded text-black" />
      <select name="is_read" class="px-2 py-1 rounded text-black">
        <option value="">All</option>
        <option value="0" <?= (@$_GET['is_read']==='0'?'selected':'') ?>>Unread</option>
        <option value="1" <?= (@$_GET['is_read']==='1'?'selected':'') ?>>Read</option>
      </select>
      <button type="submit" class="bg-yellow-500 text-black px-4 py-1 rounded">Filter</button>
    </form>

    <div class="overflow-x-auto">
      <table class="min-w-full text-xs md:text-sm">
        <thead class="bg-yellow-500 text-black">
          <tr>
            <th class="p-2">ID</th>
            <th class="p-2">User</th>
            <th class="p-2">Title</th>
            <th class="p-2">Message</th>
            <th class="p-2">Status</th>
            <th class="p-2">Date</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($notifications as $n): ?>
            <tr class="border-b border-gray-700">
              <td class="p-2">#<?= $n['id'] ?></td>
              <td class="p-2">ID: <?= $n['user_id'] ?><br><span class="text-xs text-gray-400"><?= htmlspecialchars($n['email']) ?></span></td>
              <td class="p-2"><?= htmlspecialchars($n['title']) ?></td>
              <td class="p-2 text-xs"><?= htmlspecialchars($n['message']) ?></td>
              <td class="p-2">
                <span class="px-2 py-1 rounded <?= $n['is_read'] ? 'bg-green-600' : 'bg-yellow-600' ?> text-black">
                  <?= $n['is_read'] ? 'Read' : 'Unread' ?>
                </span>
              </td>
              <td class="p-2 text-xs"><?= date('d M Y H:i', strtotime($n['created_at'])) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
      <?php if (empty($notifications)): ?>
        <div class="text-center text-gray-400 py-8">No notifications found.</div>
      <?php endif; ?>
    </div>
  </div>

  <footer class="fixed bottom-0 left-0 right-0 bg-black border-t border-gray-800 z-50">
    <div class="flex justify-around py-2 text-xs text-white">
      <a href="admin_dashboard.php" class="flex flex-col items-center hover:text-yellow-400">
        <span>🏠</span>
        <span>Home</span>
      </a>
      <a href="admin_services.php" class="flex flex-col items-center hover:text-yellow-400">
        <span>💸</span>
        <span>Prices</span>
      </a>
      <a href="admin_users.php" class="flex flex-col items-center hover:text-yellow-400">
        <span>👥</span>
        <span>Users</span>
      </a>
      <a href="admin_transactions.php" class="flex flex-col items-center hover:text-yellow-400">
        <span>📄</span>
        <span>Transactions</span>
      </a>
      <a href="admin_withdrawals.php" class="flex flex-col items-center hover:text-yellow-400">
        <span>💵</span>
        <span>Withdrawals</span>
      </a>
      <a href="admin_notifications.php" class="flex flex-col items-center text-yellow-400">
        <span>🔔</span>
        <span>Notifications</span>
      </a>
      <a href="logout.php" class="flex flex-col items-center text-red-500 hover:text-yellow-500">
        <span>🚪</span>
        <span>Logout</span>
      </a>
    </div>
  </footer>
</body>
</html>

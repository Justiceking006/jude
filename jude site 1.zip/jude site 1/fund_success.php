<?php
// ✅ Error reporting (disable in production)
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();
require_once 'connection.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$reference = $_GET['ref'] ?? '';

if (!$reference) {
    echo "⚠️ Invalid request: No reference.";
    exit;
}

// 🔐 Paystack Secret Key (LIVE)
$paystack_secret = "sk_live_xxxxxxxxxxxxxxxxx"; // Replace with your live secret key

// ✅ Verify the transaction via Paystack API
$ch = curl_init();
curl_setopt_array($ch, [
    CURLOPT_URL => "https://api.paystack.co/transaction/verify/" . $reference,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER => [
        "Authorization: Bearer $paystack_secret"
    ]
]);
$response = curl_exec($ch);
curl_close($ch);

$result = json_decode($response, true);

if (!$result || !$result['status'] || $result['data']['status'] !== 'success') {
    echo "❌ Transaction verification failed or not successful.";
    exit;
}

$data = $result['data'];
$amount = $data['amount'] / 100; // convert from kobo to Naira

// ✅ Prevent duplicate funding using reference
$check = $pdo->prepare("SELECT id FROM transactions WHERE metadata LIKE ?");
$check->execute(["%$reference%"]);
if ($check->fetch()) {
    echo "✅ Transaction already processed.";
    exit;
}

// ✅ Insert transaction
$meta_json = json_encode(["reference" => $reference, "raw" => $data]);

$pdo->prepare("INSERT INTO transactions (user_id, service, provider, amount, status, metadata, category)
               VALUES (?, 'wallet_funding', 'Paystack', ?, 'successful', ?, 'funding')")
    ->execute([$user_id, $amount, $meta_json]);

// ✅ Update wallet
$pdo->prepare("UPDATE wallets SET balance = balance + ? WHERE user_id = ?")
    ->execute([$amount, $user_id]);

// ✅ Notify user
$pdo->prepare("INSERT INTO notifications (user_id, title, message)
               VALUES (?, '💰 Wallet Funded!', ?)")
    ->execute([$user_id, "You successfully funded ₦" . number_format($amount, 2) . " via Paystack."]);

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Wallet Funded</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-black text-white flex flex-col items-center justify-center h-screen text-center">
  <h1 class="text-2xl font-bold text-gold">🎉 Payment Successful!</h1>
  <p class="mt-4 text-lg">₦<?= number_format($amount, 2) ?> has been added to your wallet.</p>
  <a href="dashboard.php" class="mt-6 bg-gold text-black px-4 py-2 rounded">Return to Dashboard</a>
</body>
</html>
<?php
session_start();
require_once '../connection.php';

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if (!$user_id) {
    die('User ID is required.');
}

// Fetch user info
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();
if (!$user) die('User not found.');

// Fetch wallet
$stmt = $pdo->prepare("SELECT * FROM wallets WHERE user_id = ?");
$stmt->execute([$user_id]);
$wallet = $stmt->fetch();

// Fetch transactions
$stmt = $pdo->prepare("SELECT * FROM transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT 20");
$stmt->execute([$user_id]);
$transactions = $stmt->fetchAll();

// Fetch referrals
$stmt = $pdo->prepare("SELECT u.id, u.email, u.first_name FROM referrals r JOIN users u ON r.referred_id = u.id WHERE r.referrer_id = ?");
$stmt->execute([$user_id]);
$referrals = $stmt->fetchAll();

// Fetch activity logs
$stmt = $pdo->prepare("SELECT * FROM activity_logs WHERE user_id = ? ORDER BY created_at DESC LIMIT 20");
$stmt->execute([$user_id]);
$logs = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>User Details - Admin</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-black text-white min-h-screen pb-24">
  <div class="bg-black text-yellow-400 px-4 py-3 flex justify-between items-center sticky top-0 z-50">
    <h1 class="text-xl font-bold">User Details</h1>
    <a href="admin_users.php" class="text-yellow-400 hover:underline">Back to Users</a>
  </div>

  <div class="p-4 max-w-3xl mx-auto">
    <div class="mb-6 bg-gray-900 rounded-lg p-4">
      <h2 class="text-lg font-semibold mb-2">Profile Info</h2>
      <div><span class="text-gray-400">ID:</span> <?= $user['id'] ?></div>
      <div><span class="text-gray-400">Name:</span> <?= htmlspecialchars($user['first_name']) ?></div>
      <div><span class="text-gray-400">Email:</span> <?= htmlspecialchars($user['email']) ?></div>
      <div><span class="text-gray-400">Phone:</span> <?= htmlspecialchars($user['phone']) ?></div>
      <div><span class="text-gray-400">Registered:</span> <?= date('d M Y', strtotime($user['created_at'])) ?></div>
      <div><span class="text-gray-400">Referral Code:</span> <?= htmlspecialchars($user['referral_code']) ?></div>
    </div>

    <div class="mb-6 bg-gray-900 rounded-lg p-4">
      <h2 class="text-lg font-semibold mb-2">Wallet</h2>
      <div><span class="text-gray-400">Balance:</span> ₦<?= number_format($wallet['balance'] ?? 0, 2) ?></div>
      <div><span class="text-gray-400">Account #:</span> <?= htmlspecialchars($wallet['account_number'] ?? '-') ?></div>
      <div><span class="text-gray-400">Bank:</span> <?= htmlspecialchars($wallet['bank_name'] ?? '-') ?></div>
      <div><span class="text-gray-400">Reference:</span> <?= htmlspecialchars($wallet['account_reference'] ?? '-') ?></div>
    </div>

    <div class="mb-6 bg-gray-900 rounded-lg p-4">
      <h2 class="text-lg font-semibold mb-2">Recent Transactions</h2>
      <div class="overflow-x-auto">
        <table class="min-w-full text-xs md:text-sm">
          <thead class="bg-yellow-500 text-black">
            <tr>
              <th class="p-2">Service</th>
              <th class="p-2">Provider</th>
              <th class="p-2">Amount</th>
              <th class="p-2">Status</th>
              <th class="p-2">Date</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($transactions as $tx): ?>
              <tr class="border-b border-gray-700">
                <td class="p-2"><?= htmlspecialchars($tx['service']) ?></td>
                <td class="p-2"><?= htmlspecialchars($tx['provider']) ?></td>
                <td class="p-2">₦<?= number_format($tx['amount'],2) ?></td>
                <td class="p-2">
                  <span class="px-2 py-1 rounded <?=
                    $tx['status']==='successful' ? 'bg-green-600' :
                    ($tx['status']==='failed' ? 'bg-red-600' : 'bg-yellow-600')
                  ?> text-black">
                    <?= ucfirst($tx['status']) ?>
                  </span>
                </td>
                <td class="p-2 text-xs"><?= date('d M Y H:i', strtotime($tx['created_at'])) ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
        <?php if (empty($transactions)): ?>
          <div class="text-center text-gray-400 py-4">No transactions found.</div>
        <?php endif; ?>
      </div>
    </div>

    <div class="mb-6 bg-gray-900 rounded-lg p-4">
      <h2 class="text-lg font-semibold mb-2">Referrals</h2>
      <ul>
        <?php foreach ($referrals as $ref): ?>
          <li class="mb-1">ID: <?= $ref['id'] ?> - <?= htmlspecialchars($ref['first_name']) ?> (<?= htmlspecialchars($ref['email']) ?>)</li>
        <?php endforeach; ?>
        <?php if (empty($referrals)): ?>
          <li class="text-gray-400">No referrals found.</li>
        <?php endif; ?>
      </ul>
    </div>

    <div class="mb-6 bg-gray-900 rounded-lg p-4">
      <h2 class="text-lg font-semibold mb-2">Recent Activity Logs</h2>
      <ul>
        <?php foreach ($logs as $log): ?>
          <li class="mb-1 text-xs">[<?= date('d M Y H:i', strtotime($log['created_at'])) ?>] <?= htmlspecialchars($log['action']) ?> - <?= htmlspecialchars($log['description']) ?></li>
        <?php endforeach; ?>
        <?php if (empty($logs)): ?>
          <li class="text-gray-400">No activity logs found.</li>
        <?php endif; ?>
      </ul>
    </div>
  </div>

  <footer class="fixed bottom-0 left-0 right-0 bg-black border-t border-gray-800 z-50">
    <div class="flex justify-around py-2 text-xs text-white">
      <a href="admin_dashboard.php" class="flex flex-col items-center hover:text-yellow-400">
        <span>🏠</span>
        <span>Home</span>
      </a>
      <a href="admin_services.php" class="flex flex-col items-center hover:text-yellow-400">
        <span>💸</span>
        <span>Prices</span>
      </a>
      <a href="admin_users.php" class="flex flex-col items-center hover:text-yellow-400">
        <span>👥</span>
        <span>Users</span>
      </a>
      <a href="admin_transactions.php" class="flex flex-col items-center hover:text-yellow-400">
        <span>📄</span>
        <span>Transactions</span>
      </a>
      <a href="admin_wallets.php" class="flex flex-col items-center hover:text-yellow-400">
        <span>💳</span>
        <span>Wallets</span>
      </a>
      <a href="admin_withdrawals.php" class="flex flex-col items-center hover:text-yellow-400">
        <span>💵</span>
        <span>Withdrawals</span>
      </a>
      <a href="admin_notifications.php" class="flex flex-col items-center hover:text-yellow-400">
        <span>🔔</span>
        <span>Notifications</span>
      </a>
      <a href="admin_activity_logs.php" class="flex flex-col items-center hover:text-yellow-400">
        <span>📋</span>
        <span>Activity Logs</span>
      </a>
      <a href="admin_profile.php" class="flex flex-col items-center hover:text-yellow-400">
        <span>⚙️</span>
        <span>Profile</span>
      </a>
      <a href="logout.php" class="flex flex-col items-center text-red-500 hover:text-yellow-500">
        <span>🚪</span>
        <span>Logout</span>
      </a>
    </div>
  </footer>
</body>
</html>

<?php
// Database configuration
$host = 'localhost';
$dbname = 'judesono_Grace_exchange';
$user = 'judesono_Jude';
$password = '1234501210@Admin';

try {
    // PDO connection
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $user, $password);
    // Set error reporting
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    // Optional: set default fetch mode to associative array
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    // If connection fails, stop the script and show error
    die("Connection failed: " . $e->getMessage());
}
?>
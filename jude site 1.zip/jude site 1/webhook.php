<?php
require_once 'connection.php';

// SECURITY: Your Monnify secret key
define('MONNIFY_WEBHOOK_SECRET', 'D62LTJ8MJ6EPSBUWFBY4GXCEMUWCC6E6');

// Capture raw payload
$payload = file_get_contents("php://input");
$data = json_decode($payload, true);

// Debug: Log the payload
file_put_contents("webhook_log.txt", date("Y-m-d H:i:s") . " - " . $payload . PHP_EOL, FILE_APPEND);

// Verify signature
$provided_signature = $_SERVER['HTTP_MONNIFY_SIGNATURE'] ?? '';
$calculated_signature = hash_hmac("sha512", $payload, MONNIFY_WEBHOOK_SECRET);

if ($provided_signature !== $calculated_signature) {
    http_response_code(401);
    exit("Invalid signature.");
}

// Check event type
if (!isset($data['eventType']) || $data['eventType'] !== 'SUCCESSFUL_TRANSACTION') {
    http_response_code(400);
    exit("Invalid event type.");
}

// Extract payment details
$payment = $data['eventData'];
$amount = floatval($payment['amountPaid']);
$account_ref = $payment['product']['reference'];
$payment_ref = $payment['paymentReference'];
$paid_at = $payment['paidOn'] ?? date("Y-m-d H:i:s");

// Prevent duplicates
$check = $pdo->prepare("SELECT id FROM transactions WHERE payment_reference = ?");
$check->execute([$payment_ref]);
if ($check->fetch()) {
    http_response_code(200);
    exit("Already processed.");
}

// Locate wallet
$stmt = $pdo->prepare("SELECT * FROM wallets WHERE account_reference = ?");
$stmt->execute([$account_ref]);
$wallet = $stmt->fetch();

if (!$wallet) {
    http_response_code(404);
    exit("Wallet not found.");
}

// Update wallet balance
$new_balance = $wallet['balance'] + $amount;
$pdo->prepare("UPDATE wallets SET balance = ? WHERE user_id = ?")
    ->execute([$new_balance, $wallet['user_id']]);

// Log transaction
$pdo->prepare("INSERT INTO transactions (user_id, amount, category, payment_reference, status, created_at)
               VALUES (?, ?, 'funding', ?, 'successful', NOW())")
    ->execute([$wallet['user_id'], $amount, $payment_ref]);

// Log activity
$pdo->prepare("INSERT INTO activity_logs (user_id, action, description)
               VALUES (?, 'Wallet Funding', ?)")
    ->execute([$wallet['user_id'], "₦" . number_format($amount, 2) . " credited via Monnify."]);

// ✅ Add notification
$pdo->prepare("INSERT INTO notifications (user_id, title, message) VALUES (?, ?, ?)")
    ->execute([
        $wallet['user_id'],
        "💳 Wallet Funded",
        "Your wallet has been credited with ₦" . number_format($amount, 2) . " successfully via Monnify."
    ]);

http_response_code(200);
echo "Wallet funded successfully.";
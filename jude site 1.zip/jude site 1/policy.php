<?php
session_start();
require_once 'connection.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// Fetch all policies
$stmt = $pdo->query("SELECT * FROM policies ORDER BY created_at DESC");
$policies = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Policies | Son of Grace Exchange</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/feather-icons"></script>
  <script>
    tailwind.config = {
      theme: {
        extend: {
          colors: {
            gold: '#FFD700',
            black: '#000000',
            white: '#ffffff',
          },
          fontFamily: {
            spaghetti: ['"Pacifico"', 'cursive'],
            body: ['Inter', 'sans-serif'],
          },
        },
      },
    };
  </script>
  <link href="https://fonts.googleapis.com/css2?family=Pacifico&family=Inter:wght@400;600&display=swap" rel="stylesheet">
</head>
<body class="bg-black text-white font-body">
  <!-- Header -->
  <header class="flex items-center justify-between p-4 border-b border-gold">
    <h1 class="font-spaghetti text-gold text-xl">Son of Grace Exchange</h1>
    <a href="more.php" class="text-gold">Back</a>
  </header>

  <!-- Main Content -->
  <main class="px-4 py-4 space-y-6">
    <h2 class="text-lg font-semibold text-gold">Platform Policies</h2>

    <?php if (empty($policies)): ?>
      <p class="text-gray-400">No policies added yet.</p>
    <?php else: ?>
      <?php foreach ($policies as $policy): ?>
        <section class="bg-white text-black rounded-lg p-4 space-y-2">
          <h3 class="text-gold text-lg font-semibold"><?= htmlspecialchars($policy['title']) ?></h3>
          <p class="text-sm"><?= nl2br(htmlspecialchars($policy['content'])) ?></p>
        </section>
      <?php endforeach; ?>
    <?php endif; ?>
  </main>

  <!-- Footer -->
  <nav class="fixed bottom-0 left-0 right-0 bg-black border-t border-gold flex justify-around items-center p-2 z-50">
    <a href="dashboard.php" class="flex flex-col items-center">
      <i data-feather="home"></i><span class="text-xs">Home</span>
    </a>
    <a href="dashboard_profile.php" class="flex flex-col items-center">
      <i data-feather="user"></i><span class="text-xs">Profile</span>
    </a>
    <a href="support.php" class="flex flex-col items-center">
      <i data-feather="phone"></i><span class="text-xs">Support</span>
    </a>
    <a href="history.php" class="flex flex-col items-center">
      <i data-feather="clock"></i><span class="text-xs">History</span>
    </a>
    <a href="more.php" class="flex flex-col items-center text-white font-bold">
      <i data-feather="menu"></i><span class="text-xs">More</span>
    </a>
  </nav>

  <script>feather.replace();</script>
</body>
</html>
<?php
session_start();
require_once 'connection.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Fetch user info
$stmt = $pdo->prepare("SELECT referral_code, first_name FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

// Total referral earnings
$earnings_stmt = $pdo->prepare("SELECT SUM(earnings) AS total_earnings FROM referrals WHERE referrer_id = ?");
$earnings_stmt->execute([$user_id]);
$earnings = $earnings_stmt->fetchColumn();

$referral_link = "https://judesonofgraceexchange.com/register.php?ref=" . urlencode($user['referral_code']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Share & Earn | Son of Grace Exchange</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/feather-icons"></script>
  <script>
    tailwind.config = {
      theme: {
        extend: {
          colors: {
            gold: '#FFD700',
            black: '#000000',
            white: '#ffffff',
          },
          fontFamily: {
            spaghetti: ['"Pacifico"', 'cursive'],
            body: ['Inter', 'sans-serif'],
          },
        },
      },
    };
  </script>
</head>
<body class="bg-black text-white font-body">
  <header class="flex items-center justify-between p-4 border-b border-gold">
    <h1 class="text-gold font-spaghetti text-xl">Son of Grace Exchange</h1>
    <a href="more.php" class="text-gold">Back</a>
  </header>

  <main class="p-4 space-y-6">
    <section>
      <h2 class="text-lg font-semibold text-gold">Hi, <?= htmlspecialchars($user['first_name']) ?>!</h2>
      <p class="text-sm text-gray-300">Refer and earn when friends join using your link.</p>
    </section>

    <section>
      <label class="block text-sm text-gold mb-2">Your Referral Link</label>
      <div class="flex items-center bg-white rounded-lg text-black overflow-hidden">
        <input id="refLink" type="text" value="<?= htmlspecialchars($referral_link) ?>" class="flex-1 p-2 bg-transparent focus:outline-none" readonly>
        <button onclick="copyLink()" class="px-4 py-2 bg-gold text-black font-semibold">Copy</button>
      </div>
    </section>

    <section>
      <p class="text-gold text-sm">Total Referral Earnings:</p>
      <h3 class="text-2xl font-bold">₦<?= number_format($earnings ?? 0, 2) ?></h3>
    </section>

    <section class="space-y-3">
      <button onclick="shareWhatsApp()" class="w-full bg-green-500 text-white py-2 rounded-lg">Share via WhatsApp</button>
      <button onclick="shareSystem()" class="w-full bg-blue-600 text-white py-2 rounded-lg">Share via System</button>
    </section>
  </main>

  <nav class="fixed bottom-0 left-0 right-0 bg-black border-t border-gold flex justify-around items-center p-2 z-50">
    <a href="dashboard.php" class="nav-item flex flex-col items-center">
      <i data-feather="home"></i><span class="text-xs">Home</span>
    </a>
    <a href="dashboard_profile.php" class="nav-item flex flex-col items-center">
      <i data-feather="user"></i><span class="text-xs">Profile</span>
    </a>
    <a href="support.php" class="nav-item flex flex-col items-center">
      <i data-feather="phone"></i><span class="text-xs">Support</span>
    </a>
    <a href="history.php" class="nav-item flex flex-col items-center">
      <i data-feather="clock"></i><span class="text-xs">History</span>
    </a>
    <a href="more.php" class="nav-item flex flex-col items-center text-white font-bold">
      <i data-feather="menu"></i><span class="text-xs">More</span>
    </a>
  </nav>

  <script>
    feather.replace();

    function copyLink() {
      const input = document.getElementById("refLink");
      input.select();
      document.execCommand("copy");
      alert("Referral link copied!");
    }

    function shareWhatsApp() {
      const link = document.getElementById("refLink").value;
      const message = encodeURIComponent("Join Son of Grace Exchange and earn! Register here: " + link);
      window.open("https://wa.me/?text=" + message, "_blank");
    }

    function shareSystem() {
      const link = document.getElementById("refLink").value;
      const message = "Join Son of Grace Exchange and earn! Register here: " + link;
      if (navigator.share) {
        navigator.share({
          title: "Earn with Son of Grace",
          text: message,
          url: link
        }).catch(console.error);
      } else {
        alert("Your device doesn't support system sharing.");
      }
    }
  </script>
</body>
</html>
<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Admin Login</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-black min-h-screen flex items-center justify-center">
  <div class="w-full max-w-md p-6 bg-gray-900 rounded-2xl shadow-lg mx-4">
    <h1 class="text-center text-3xl font-bold text-yellow-500 mb-6">Admin Login</h1>

    <?php if (isset($_SESSION['error'])): ?>
      <div class="bg-red-600 text-white p-3 rounded mb-4 text-center">
        <?= htmlspecialchars($_SESSION['error']) ?>
      </div>
      <?php unset($_SESSION['error']); ?>
    <?php endif; ?>

    <form action="login_script.php" method="POST" class="space-y-4">
      <div>
        <label class="block text-sm mb-1 text-white">Email</label>
        <input type="email" name="email" required
               class="w-full px-4 py-3 rounded-lg bg-gray-800 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-yellow-500" />
      </div>

      <div>
        <label class="block text-sm mb-1 text-white">Password</label>
        <input type="password" name="password" required
               class="w-full px-4 py-3 rounded-lg bg-gray-800 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-yellow-500" />
      </div>

      <button type="submit"
              class="w-full bg-yellow-500 hover:bg-yellow-600 text-black font-semibold py-3 rounded-lg transition-all">
        Login
      </button>
    </form>
  </div>
</body>
</html>
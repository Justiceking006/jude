<?php
// ✅ Enable error reporting (disable in production)
ini_set('display_errors', 1);
error_reporting(E_ALL);

// ✅ DB connection
require_once 'connection.php';

// ✅ Use environment variable or include secure config
$paystack_secret = "sk_live_8a600c0130b2ff273760b14438536d6abaecd4c0"; // 🔁 Replace with **LIVE SECRET KEY**

$input = @file_get_contents("php://input");
$event = json_decode($input, true);

// ✅ Verify Paystack Signature
$signature = $_SERVER['HTTP_X_PAYSTACK_SIGNATURE'] ?? '';
if (!$signature || !hash_equals(hash_hmac('sha512', $input, $paystack_secret), $signature)) {
    http_response_code(401);
    exit("❌ Invalid signature.");
}

// ✅ Process successful charge only
if ($event['event'] === 'charge.success') {
    $data = $event['data'];
    $user_id = $data['metadata']['user_id'] ?? null;
    $amount = $data['amount'] / 100; // Convert from kobo
    $reference = $data['reference'];

    if ($user_id && $amount > 0) {
        // ✅ Check for duplicate
        $check = $pdo->prepare("SELECT id FROM transactions WHERE reference = ?");
        $check->execute([$reference]);

        if (!$check->fetch()) {
            // ✅ Insert into transactions
            $stmt = $pdo->prepare("INSERT INTO transactions (user_id, amount, reference, status, service, provider, category, created_at)
                                   VALUES (?, ?, ?, 'successful', 'wallet_funding', 'Paystack', 'funding', NOW())");
            $stmt->execute([$user_id, $amount, $reference]);

            // ✅ Update wallet balance
            $wallet = $pdo->prepare("UPDATE wallets SET balance = balance + ? WHERE user_id = ?");
            $wallet->execute([$amount, $user_id]);

            // ✅ Send notification
            $pdo->prepare("INSERT INTO notifications (user_id, title, message)
                           VALUES (?, '💰 Wallet Funded!', ?)")
                ->execute([$user_id, "You funded ₦" . number_format($amount, 2) . " successfully."]);
        }
    }
}

// ✅ Success response to Paystack
http_response_code(200);
echo "✅ OK";
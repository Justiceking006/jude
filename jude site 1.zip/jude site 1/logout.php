<?php
session_start();
require_once 'connection.php';

function logActivity($pdo, $user_id, $action, $description = null) {
    $stmt = $pdo->prepare("INSERT INTO activity_logs (user_id, action, description) VALUES (?, ?, ?)");
    $stmt->execute([$user_id, $action, $description]);
}

// Check if user is logged in before destroying session
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    logActivity($pdo, $user_id, 'Logout', 'User logged out.');
}

// Unset all session variables
$_SESSION = [];

// Destroy the session
session_destroy();

// Redirect to login page
header("Location: login.html");
exit;
<?php
session_start();
require_once 'connection.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// ✅ Mark all unread notifications as read
$pdo->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ? AND is_read = 0")->execute([$user_id]);

// ✅ Fetch all notifications
$stmt = $pdo->prepare("SELECT title, message, created_at FROM notifications WHERE user_id = ? ORDER BY created_at DESC");
$stmt->execute([$user_id]);
$notifications = $stmt->fetchAll(PDO::FETCH_ASSOC);

// ✅ TEMPORARY WALLET DEBUG CHECK
$stmt = $pdo->prepare("SELECT * FROM wallets WHERE user_id = ?");
$stmt->execute([$user_id]);
$wallet = $stmt->fetch();

if (!$wallet) {
    $notifications[] = [
        'title' => "🚨 Wallet Missing",
        'message' => "No wallet found for your account. Please contact support or try registering again.",
        'created_at' => date('Y-m-d H:i:s')
    ];
} else {
    $notifications[] = [
        'title' => "✅ Wallet Debug Info",
        'message' => "Bank: {$wallet['bank_name']} | Acc No: {$wallet['account_number']} | Ref: {$wallet['account_reference']}",
        'created_at' => date('Y-m-d H:i:s')
    ];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Notifications | Son of Grace Exchange</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/feather-icons"></script>
  <script>
    tailwind.config = {
      theme: {
        extend: {
          colors: {
            gold: '#FFD700',
            black: '#000000',
            white: '#ffffff',
          },
          fontFamily: {
            spaghetti: ['"Pacifico"', 'cursive'],
            body: ['Inter', 'sans-serif'],
          },
        },
      },
    };
  </script>
</head>
<body class="bg-black text-white font-body">
  <!-- Header -->
  <header class="flex items-center justify-between p-4 border-b border-gold">
    <h1 class="text-xl font-spaghetti text-gold">Son of Grace Exchange</h1>
    <a href="more.php" class="text-gold">Back</a>
  </header>

  <!-- Main -->
  <main class="p-4 space-y-4">
    <h2 class="text-lg font-bold text-gold">Notifications</h2>

    <?php if (empty($notifications)): ?>
      <p class="text-gray-400">You have no notifications yet.</p>
    <?php else: ?>
      <ul class="space-y-4">
        <?php foreach ($notifications as $note): ?>
          <li class="bg-white text-black p-4 rounded shadow">
            <h3 class="font-bold text-base"><?= htmlspecialchars($note['title']) ?></h3>
            <p class="text-sm"><?= htmlspecialchars($note['message']) ?></p>
            <p class="text-xs text-gray-600 mt-1"><?= date("M d, Y H:i", strtotime($note['created_at'])) ?></p>
          </li>
        <?php endforeach; ?>
      </ul>
    <?php endif; ?>
  </main>

  <!-- Bottom Nav -->
  <nav class="fixed bottom-0 left-0 right-0 bg-black border-t border-gold flex justify-around items-center p-2 z-50">
    <a href="dashboard.php" class="nav-item flex flex-col items-center"><i data-feather="home"></i><span class="text-xs">Home</span></a>
    <a href="dashboard_profile.php" class="nav-item flex flex-col items-center"><i data-feather="user"></i><span class="text-xs">Profile</span></a>
    <a href="support.php" class="nav-item flex flex-col items-center"><i data-feather="phone"></i><span class="text-xs">Support</span></a>
    <a href="history.php" class="nav-item flex flex-col items-center"><i data-feather="clock"></i><span class="text-xs">History</span></a>
    <a href="more.php" class="nav-item flex flex-col items-center text-white font-bold"><i data-feather="menu"></i><span class="text-xs">More</span></a>
  </nav>

  <script>feather.replace();</script>
</body>
</html>
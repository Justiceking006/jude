<?php
session_start();
require_once 'connection.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
// Fetch user name
$stmt = $pdo->prepare("SELECT first_name FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$row = $stmt->fetch();
$name = $row['first_name'] ?? 'User';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>CAC Registration | Son of Grace Exchange</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/feather-icons"></script>
  <script>
    tailwind.config = {
      theme: {
        extend: {
          colors: {
            gold: '#FFD700',
            black: '#000000',
            white: '#ffffff',
          },
          fontFamily: {
            spaghetti: ['"Pacifico"', 'cursive'],
            body: ['Inter', 'sans-serif'],
          },
        },
      },
    };
  </script>
</head>
<body class="bg-black text-white font-body">

<!-- ✅ Header -->
<header class="flex items-center justify-between p-4 border-b border-gold">
  <h1 class="text-xl font-spaghetti text-gold">Son of Grace Exchange</h1>
  <a href="dashboard.php" class="text-gold">Back</a>
</header>

<!-- ✅ Main -->
<main class="p-4 pb-32 space-y-6">
  <section class="space-y-2">
    <h2 class="text-lg font-semibold text-gold">🏛 Register Your Business with CAC</h2>
    <p class="text-sm text-white">
      Want to register a Business Name, Limited Company, or NGO with CAC? Fill the form below to get started with Son of Grace Exchange. We offer fast and affordable registration! 📄
    </p>
  </section>

  <form id="cacForm" class="space-y-4">
    <input type="text" id="full_name" class="w-full p-2 rounded bg-white text-black" placeholder="Full Name" required>
    <input type="tel" id="phone" class="w-full p-2 rounded bg-white text-black" placeholder="Phone Number" required>

    <select id="reg_type" class="w-full p-2 rounded bg-white text-black" required>
      <option value="">Select Registration Type</option>
      <option value="Business Name">Business Name</option>
      <option value="Limited (LTD)">Limited (LTD)</option>
      <option value="Incorporated Trustees (NGO)">Incorporated Trustees (NGO)</option>
    </select>

    <input type="text" id="business_name" class="w-full p-2 rounded bg-white text-black" placeholder="Proposed Business Name" required>
    <input type="email" id="email" class="w-full p-2 rounded bg-white text-black" placeholder="Email Address" required>
    <textarea id="note" rows="3" class="w-full p-2 rounded bg-white text-black" placeholder="Additional Note (Optional)"></textarea>

    <button type="submit" class="w-full bg-gold text-black py-2 px-4 rounded font-semibold hover:bg-yellow-500 transition">
      Submit & Contact Admin
    </button>
  </form>
</main>

<!-- ✅ Bottom Navigation -->
<nav class="fixed bottom-0 left-0 right-0 bg-black border-t border-gold flex justify-around items-center p-2 z-50">
  <a href="dashboard.php" class="flex flex-col items-center"><i data-feather="home"></i><span class="text-xs">Home</span></a>
  <a href="dashboard_profile.php" class="flex flex-col items-center"><i data-feather="user"></i><span class="text-xs">Profile</span></a>
  <a href="support.php" class="flex flex-col items-center"><i data-feather="phone"></i><span class="text-xs">Support</span></a>
  <a href="history.php" class="flex flex-col items-center"><i data-feather="clock"></i><span class="text-xs">History</span></a>
  <a href="more.php" class="flex flex-col items-center"><i data-feather="menu"></i><span class="text-xs">More</span></a>
</nav>

<!-- ✅ JavaScript -->
<script>
  feather.replace();

  const form = document.getElementById('cacForm');
  form.addEventListener('submit', function(e) {
    e.preventDefault();

    const name = document.getElementById('full_name').value;
    const phone = document.getElementById('phone').value;
    const regType = document.getElementById('reg_type').value;
    const bizName = document.getElementById('business_name').value;
    const email = document.getElementById('email').value;
    const note = document.getElementById('note').value;

    const message = `🏛 New CAC Registration Request\n\nName: ${name}\nPhone: ${phone}\nRegistration Type: ${regType}\nProposed Business Name: ${bizName}\nEmail: ${email}\nNote: ${note || 'None'}\n\nSent from Son of Grace Exchange`;

    const whatsappNumber = '+2348108255139'; // 🟡 Replace with real admin number
    const url = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(message)}`;
    window.location.href = url;
  });
</script>
</body>
</html>
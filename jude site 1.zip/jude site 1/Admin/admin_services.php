<?php
session_start();
require_once 'connection.php';

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit;
}

// Handle update request
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $id = $_POST['id'];
    $user_price = $_POST['user_price'];
    $reseller_price = $_POST['reseller_price'];
    $api_price = $_POST['api_user_price'];

    $stmt = $pdo->prepare("UPDATE services SET user_price = ?, reseller_price = ?, api_user_price = ? WHERE id = ?");
    $stmt->execute([$user_price, $reseller_price, $api_price, $id]);

    echo json_encode(["status" => "success"]);
    exit;
}

$services = $pdo->query("SELECT * FROM services ORDER BY category, network, plan_name")->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Manage Services</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-black text-white pb-28">

  <!-- Header -->
  <div class="bg-black text-yellow-400 px-4 py-3 flex justify-between items-center sticky top-0 z-50">
    <h1 class="text-lg font-bold">Manage Prices</h1>
    <a href="admin_dashboard.php" class="text-yellow-500 text-sm">🏠 Dashboard</a>
  </div>

  <!-- Table -->
  <div class="overflow-x-auto p-4">
    <table class="min-w-full text-sm bg-white text-black rounded-lg overflow-hidden shadow">
      <thead class="bg-gray-800 text-white">
        <tr>
          <th class="p-2">Category</th>
          <th class="p-2">Network</th>
          <th class="p-2">Plan</th>
          <th class="p-2">Type</th>
          <th class="p-2">Service ID</th>
          <th class="p-2">User</th>
          <th class="p-2">Reseller</th>
          <th class="p-2">API</th>
          <th class="p-2">Action</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($services as $service): ?>
        <tr id="row-<?= $service['id'] ?>" class="border-b hover:bg-gray-100">
          <td class="p-2"><?= htmlspecialchars($service['category']) ?></td>
          <td class="p-2"><?= htmlspecialchars($service['network']) ?></td>
          <td class="p-2"><?= htmlspecialchars($service['plan_name']) ?></td>
          <td class="p-2"><?= htmlspecialchars($service['type']) ?></td>
          <td class="p-2"><?= htmlspecialchars($service['service_id']) ?></td>
          <td class="p-2">
            <input type="number" class="user_price w-full px-2 py-1 border rounded" value="<?= $service['user_price'] ?>">
          </td>
          <td class="p-2">
            <input type="number" class="reseller_price w-full px-2 py-1 border rounded" value="<?= $service['reseller_price'] ?>">
          </td>
          <td class="p-2">
            <input type="number" class="api_user_price w-full px-2 py-1 border rounded" value="<?= $service['api_user_price'] ?>">
          </td>
          <td class="p-2">
            <button onclick="updatePrice(<?= $service['id'] ?>)" class="bg-yellow-500 hover:bg-yellow-600 text-black px-3 py-1 rounded">Update</button>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>

  <!-- Admin Footer Navigation -->
  <footer class="fixed bottom-0 left-0 right-0 bg-black border-t border-gray-800 z-50">
    <div class="flex justify-around py-2 text-xs text-white">
      <a href="admin_dashboard.php" class="flex flex-col items-center text-yellow-400">
        <span>🏠</span>
        <span>Home</span>
      </a>
      <a href="admin_services.php" class="flex flex-col items-center text-yellow-400">
        <span>💸</span>
        <span>Prices</span>
      </a>
      <a href="admin_users.php" class="flex flex-col items-center hover:text-yellow-400">
        <span>👥</span>
        <span>Users</span>
      </a>
      <a href="admin_funds.php" class="flex flex-col items-center hover:text-yellow-400">
        <span>💰</span>
        <span>Funds</span>
      </a>
      <a href="logout.php" class="flex flex-col items-center text-red-500 hover:text-yellow-500">
        <span>🚪</span>
        <span>Logout</span>
      </a>
    </div>
  </footer>

  <!-- JS -->
  <script>
    function updatePrice(id) {
      const row = document.getElementById('row-' + id);
      const user_price = row.querySelector('.user_price').value;
      const reseller_price = row.querySelector('.reseller_price').value;
      const api_user_price = row.querySelector('.api_user_price').value;

      fetch("admin_services.php", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: `id=${id}&user_price=${user_price}&reseller_price=${reseller_price}&api_user_price=${api_user_price}`
      }).then(res => res.json())
        .then(data => {
          if (data.status === 'success') {
            alert("Price updated!");
          }
        });
    }
  </script>
</body>
</html>
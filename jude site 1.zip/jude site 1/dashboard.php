<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
require_once 'connection.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Fetch user data
$user_stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$user_stmt->execute([$user_id]);
$user = $user_stmt->fetch();
$first_name = htmlspecialchars($user['first_name'] ?? 'User');

// Wallet balance
$wallet_stmt = $pdo->prepare("SELECT balance FROM wallets WHERE user_id = ?");
$wallet_stmt->execute([$user_id]);
$wallet = $wallet_stmt->fetch();
$wallet_balance = isset($wallet['balance']) ? (float)$wallet['balance'] : 0.00;

// Referral earnings
$referral_stmt = $pdo->prepare("SELECT SUM(earnings) AS total_earnings FROM referrals WHERE referrer_id = ?");
$referral_stmt->execute([$user_id]);
$referral_data = $referral_stmt->fetch();
$referral_earnings = isset($referral_data['total_earnings']) ? (float)$referral_data['total_earnings'] : 0.00;

// Fetch unread notification count
$notif_stmt = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0");
$notif_stmt->execute([$user_id]);
$unread_count = (int) $notif_stmt->fetchColumn();
?><!DOCTYPE html><html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Son of Grace Exchange - Dashboard</title>
  <style>
    .nav-item {
      transition: all 0.3s ease;
    }
    .nav-item:hover {
      color: #FFD700;
    }
  </style>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/feather-icons"></script>
  <script>
    tailwind.config = {
      theme: {
        extend: {
          colors: {
            gold: '#FFD700',
            black: '#000000',
            white: '#ffffff',
          },
          fontFamily: {
            spaghetti: ['"Pacifico"', 'cursive'],
            body: ['Inter', 'sans-serif'],
          },
        },
      },
    };
  </script>
  <link href="https://fonts.googleapis.com/css2?family=Pacifico&family=Inter:wght@400;600&display=swap" rel="stylesheet">
</head>
<body class="bg-black text-white font-body">
  <header class="flex items-center justify-between p-4 border-b border-gold">
    <h1 class="font-spaghetti text-gold text-xl">Son of Grace Exchange</h1>
    <div class="flex space-x-4 relative">
      <a href="notifications.php" class="relative">
        <i data-feather="bell" class="text-gold"></i>
        <?php if ($unread_count > 0): ?>
          <span class="absolute -top-2 -right-2 bg-red-600 text-white text-xs font-bold px-1.5 py-0.5 rounded-full">
            <?= $unread_count ?>
          </span>
        <?php endif; ?>
      </a>
      <a href="logout.php"><i data-feather="power" class="text-gold cursor-pointer"></i></a>
    </div>
  </header>
  <section class="p-4">
    <div class="bg-gold text-black p-4 rounded-xl flex items-center justify-between">
      <div>
        <h2 class="text-lg font-semibold">Hi, <?= $first_name ?></h2>
        <div class="flex items-center space-x-2">
          <span id="walletAmount" class="text-2xl font-bold">₦ <?= number_format($wallet_balance, 2) ?></span>
          <i id="toggleBalance" data-feather="eye-off" class="cursor-pointer"></i>
        </div>
      </div>
      <i data-feather="wallet" class="text-black"></i>
    </div>
  </section>
  <section class="px-4 mb-6">
    <div class="grid grid-cols-2 gap-4">
      <a href="fund.php" class="bg-gold text-black py-3 rounded-xl font-semibold flex items-center justify-center space-x-2">
        <i data-feather="plus"></i><span>Add Money</span>
      </a>
      <a href="history.php" class="bg-gold text-black py-3 rounded-xl font-semibold flex items-center justify-center space-x-2">
        <i data-feather="clock"></i><span>History</span>
      </a>
    </div>
  </section>
  <section class="px-4 mb-6">
    <div class="grid grid-cols-3 gap-4">
      <a href="airtime.php" class="flex flex-col items-center space-y-2">
        <div class="bg-white text-gold p-4 rounded-full">
          <i data-feather="phone"></i>
        </div>
        <span class="text-sm">Airtime</span>
      </a>
      <a href="data.php" class="flex flex-col items-center space-y-2">
        <div class="bg-white text-gold p-4 rounded-full">
          <i data-feather="wifi"></i>
        </div>
        <span class="text-sm">Data</span>
      </a>
      <a href="pos.php" class="flex flex-col items-center space-y-2">
        <div class="bg-white text-gold p-4 rounded-full">
          <i data-feather="credit-card"></i>
        </div>
        <span class="text-sm">POS</span>
      </a>
      <a href="giftcard.php" class="flex flex-col items-center space-y-2">
        <div class="bg-white text-gold p-4 rounded-full">
          <i data-feather="gift"></i>
        </div>
        <span class="text-sm">Gift Card</span>
      </a>
      <a href="cac.php" class="flex flex-col items-center space-y-2">
        <div class="bg-white text-gold p-4 rounded-full">
          <i data-feather="file-text"></i>
        </div>
        <span class="text-sm">CAC Reg.</span>
      </a>
      <a href="currency.php" class="flex flex-col items-center space-y-2">
        <div class="bg-white text-gold p-4 rounded-full">
          <i data-feather="dollar-sign"></i>
        </div>
        <span class="text-sm">Currency Ex.</span>
      </a>
      <a href="bills.php" class="flex flex-col items-center space-y-2">
        <div class="bg-white text-gold p-4 rounded-full">
          <i data-feather="tv"></i>
        </div>
        <span class="text-sm">Bill Payment</span>
      </a>
      <a href="subscription.php" class="flex flex-col items-center space-y-2">
        <div class="bg-white text-gold p-4 rounded-full">
          <i data-feather="check-circle"></i>
        </div>
        <span class="text-sm">Subscription</span>
      </a>
    </div>
  </section>
  <section class="px-4 mb-24">
    <h3 class="text-gold font-semibold mb-2">Your Overview</h3>
    <div class="bg-black border border-gold text-gold rounded-xl p-4 space-y-2">
      <div class="flex justify-between"><span>Last Login</span><span>Today</span></div>
      <div class="flex justify-between"><span>Wallet Balance</span><span>₦ <?= number_format($wallet_balance, 2) ?></span></div>
      <div class="flex justify-between"><span>Referral Earnings</span><span>₦ <?= number_format($referral_earnings, 2) ?></span></div>
    </div>
  </section>
  <nav class="fixed bottom-0 left-0 right-0 bg-black border-t border-gold flex justify-around items-center p-2 z-50" id="bottom-nav">
    <a href="dashboard.php" class="nav-item flex flex-col items-center">
      <i data-feather="home"></i>
      <span class="text-xs">Home</span>
    </a>
    <a href="dashboard_profile.php" class="nav-item flex flex-col items-center">
      <i data-feather="user"></i>
      <span class="text-xs">Profile</span>
    </a>
    <a href="support.php" class="nav-item flex flex-col items-center">
      <i data-feather="phone"></i>
      <span class="text-xs">Support</span>
    </a>
    <a href="history.php" class="nav-item flex flex-col items-center">
      <i data-feather="clock"></i>
      <span class="text-xs">History</span>
    </a>
    <a href="more.php" class="nav-item flex flex-col items-center">
      <i data-feather="menu"></i>
      <span class="text-xs">More</span>
    </a>
  </nav>
  <script>
    feather.replace();
    const toggle = document.getElementById('toggleBalance');
    const balance = document.getElementById('walletAmount');
    let visible = false;toggle?.addEventListener('click', () => {
  visible = !visible;
  balance.textContent = visible ? '₦ <?= number_format($wallet_balance, 2) ?>' : '₦ ********';
  toggle.innerHTML = visible ? feather.icons["eye"].toSvg() : feather.icons["eye-off"].toSvg();
});

  </script>
</body>
</html>
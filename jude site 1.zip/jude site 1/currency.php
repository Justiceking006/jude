<?php
session_start();
require_once 'connection.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT first_name FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();
$first_name = $user['first_name'] ?? 'User';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Currency Exchange | Son of Grace Exchange</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/feather-icons"></script>
  <script>
    tailwind.config = {
      theme: {
        extend: {
          colors: {
            gold: '#FFD700',
            black: '#000000',
            white: '#ffffff',
          },
          fontFamily: {
            spaghetti: ['"Pacifico"', 'cursive'],
            body: ['Inter', 'sans-serif'],
          },
        },
      },
    };
  </script>
</head>
<body class="bg-black text-white font-body">

<!-- ✅ Header -->
<header class="flex items-center justify-between p-4 border-b border-gold">
  <h1 class="text-xl font-spaghetti text-gold">Son of Grace Exchange</h1>
  <a href="dashboard.php" class="text-gold">Back</a>
</header>

<!-- ✅ Main Content -->
<main class="p-4 pb-32 space-y-6">
  <section class="space-y-2">
    <h2 class="text-lg font-semibold text-gold">💱 Currency Exchange Service</h2>
    <p class="text-sm text-white">
      Want to exchange USD, EUR, BTC or other currencies? You can buy or sell securely via Son of Grace Exchange. Fill the form below and we’ll reach out immediately.
    </p>
  </section>

  <form id="currencyForm" class="space-y-4">
    <input type="text" id="name" class="w-full p-2 rounded bg-white text-black" placeholder="Full Name" required>
    <input type="tel" id="phone" class="w-full p-2 rounded bg-white text-black" placeholder="Phone Number" required>

    <select id="currency" class="w-full p-2 rounded bg-white text-black" required>
      <option value="">Select Currency</option>
      <option value="USD">USD (Dollar)</option>
      <option value="EUR">EUR (Euro)</option>
      <option value="GBP">GBP (Pounds)</option>
      <option value="BTC">BTC (Bitcoin)</option>
      <option value="USDT">USDT (Tether)</option>
      <option value="Others">Other</option>
    </select>

    <input type="number" id="amount" class="w-full p-2 rounded bg-white text-black" placeholder="Amount" required>

    <select id="exchangeType" class="w-full p-2 rounded bg-white text-black" required>
      <option value="">Buy or Sell?</option>
      <option value="Buying">I want to BUY</option>
      <option value="Selling">I want to SELL</option>
    </select>

    <textarea id="note" rows="3" class="w-full p-2 rounded bg-white text-black" placeholder="Additional Note (Optional)"></textarea>

    <button type="submit" class="w-full bg-gold text-black py-2 px-4 rounded font-semibold hover:bg-yellow-500 transition">
      Submit & Contact Admin
    </button>
  </form>
</main>

<!-- ✅ Bottom Nav -->
<nav class="fixed bottom-0 left-0 right-0 bg-black border-t border-gold flex justify-around items-center p-2 z-50">
  <a href="dashboard.php" class="flex flex-col items-center"><i data-feather="home"></i><span class="text-xs">Home</span></a>
  <a href="dashboard_profile.php" class="flex flex-col items-center"><i data-feather="user"></i><span class="text-xs">Profile</span></a>
  <a href="support.php" class="flex flex-col items-center"><i data-feather="phone"></i><span class="text-xs">Support</span></a>
  <a href="history.php" class="flex flex-col items-center"><i data-feather="clock"></i><span class="text-xs">History</span></a>
  <a href="more.php" class="flex flex-col items-center"><i data-feather="menu"></i><span class="text-xs">More</span></a>
</nav>

<!-- ✅ WhatsApp Logic -->
<script>
  feather.replace();

  const form = document.getElementById('currencyForm');
  form.addEventListener('submit', function(e) {
    e.preventDefault();

    const name = document.getElementById('name').value;
    const phone = document.getElementById('phone').value;
    const currency = document.getElementById('currency').value;
    const amount = document.getElementById('amount').value;
    const exchangeType = document.getElementById('exchangeType').value;
    const note = document.getElementById('note').value;

    const message = `💱 New Currency Exchange Request\n\nName: ${name}\nPhone: ${phone}\nCurrency: ${currency}\nAmount: ${amount}\nAction: ${exchangeType}\nNote: ${note || 'None'}\n\nSent from Son of Grace Exchange`;

    const whatsappNumber = '+2348108255139'; // 🔁 Replace with your admin number
    const url = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(message)}`;
    window.location.href = url;
  });
</script>
</body>
</html>
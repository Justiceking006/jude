<?php
session_start();
require_once 'connection.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Filters
$category_filter = $_GET['category'] ?? '';
$status_filter = $_GET['status'] ?? '';
$sort_order = $_GET['sort'] === 'asc' ? 'ASC' : 'DESC';

// Build query
$sql = "SELECT * FROM transactions WHERE user_id = ?";
$params = [$user_id];

if ($category_filter) {
    $sql .= " AND category = ?";
    $params[] = $category_filter;
}
if ($status_filter) {
    $sql .= " AND status = ?";
    $params[] = $status_filter;
}
$sql .= " ORDER BY created_at $sort_order";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$transactions = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>History | Son of Grace Exchange</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/feather-icons"></script>
  <script>
    tailwind.config = {
      theme: {
        extend: {
          colors: {
            gold: '#FFD700',
            black: '#000000',
            white: '#ffffff',
          },
          fontFamily: {
            spaghetti: ['"Pacifico"', 'cursive'],
            body: ['Inter', 'sans-serif'],
          },
        },
      },
    }
  </script>
  <link href="https://fonts.googleapis.com/css2?family=Pacifico&family=Inter:wght@400;600&display=swap" rel="stylesheet">
</head>
<body class="bg-black text-white font-body">
  <header class="flex items-center justify-between p-4 border-b border-gold">
    <h1 class="font-spaghetti text-gold text-xl">Son of Grace Exchange</h1>
    <a href="dashboard.php" class="text-gold">Back</a>
  </header>

  <main class="px-4 py-3 space-y-4">
    <h2 class="text-lg font-semibold text-gold mb-2">Transaction History</h2>

    <!-- Filter Form -->
    <form method="GET" class="grid grid-cols-3 gap-2 text-black">
      <select name="category" class="rounded px-2 py-1">
        <option value="">All Types</option>
        <option value="funding" <?= $category_filter === 'funding' ? 'selected' : '' ?>>Funding</option>
        <option value="withdrawal" <?= $category_filter === 'withdrawal' ? 'selected' : '' ?>>Withdrawal</option>
        <option value="purchase" <?= $category_filter === 'purchase' ? 'selected' : '' ?>>Purchase</option>
      </select>

      <select name="status" class="rounded px-2 py-1">
        <option value="">All Status</option>
        <option value="pending" <?= $status_filter === 'pending' ? 'selected' : '' ?>>Pending</option>
        <option value="successful" <?= $status_filter === 'successful' ? 'selected' : '' ?>>Successful</option>
        <option value="failed" <?= $status_filter === 'failed' ? 'selected' : '' ?>>Failed</option>
      </select>

      <select name="sort" class="rounded px-2 py-1">
        <option value="desc" <?= $sort_order === 'DESC' ? 'selected' : '' ?>>Newest First</option>
        <option value="asc" <?= $sort_order === 'ASC' ? 'selected' : '' ?>>Oldest First</option>
      </select>

      <button type="submit" class="col-span-3 bg-gold text-black py-1 rounded mt-2">Apply Filters</button>
    </form>

    <?php if (empty($transactions)): ?>
      <p class="text-gray-400">No transactions yet.</p>
    <?php else: ?>
      <div class="space-y-3">
        <?php foreach ($transactions as $tx): ?>
          <div class="bg-white text-black rounded-lg p-3 flex justify-between items-center">
            <div>
              <p class="font-semibold capitalize">Type: <?= htmlspecialchars($tx['category']) ?></p>
              <p class="text-sm text-gray-600">Status: <?= htmlspecialchars($tx['status']) ?> | <?= date('M j, Y H:i', strtotime($tx['created_at'])) ?></p>
            </div>
            <div class="text-right">
              <p class="font-bold">₦<?= number_format($tx['amount'], 2) ?></p>
              <?php if (!empty($tx['description'])): ?>
                <p class="text-xs text-gray-600"><?= htmlspecialchars($tx['description']) ?></p>
              <?php endif; ?>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </main>

  <!-- Bottom Nav -->
  <nav class="fixed bottom-0 left-0 right-0 bg-black border-t border-gold flex justify-around items-center p-2 z-50">
    <a href="dashboard.php" class="nav-item flex flex-col items-center">
      <i data-feather="home"></i><span class="text-xs">Home</span>
    </a>
    <a href="dashboard_profile.php" class="nav-item flex flex-col items-center">
      <i data-feather="user"></i><span class="text-xs">Profile</span>
    </a>
    <a href="support.php" class="nav-item flex flex-col items-center">
      <i data-feather="phone"></i><span class="text-xs">Support</span>
    </a>
    <a href="history.php" class="nav-item flex flex-col items-center text-white font-bold">
      <i data-feather="clock"></i><span class="text-xs">History</span>
    </a>
    <a href="more.php" class="nav-item flex flex-col items-center">
      <i data-feather="menu"></i><span class="text-xs">More</span>
    </a>
  </nav>
  <script>feather.replace();</script>
</body>
</html>
<?php
session_start();
require_once 'connection.php';

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
  header("Location: login.php");
  exit;
}

// Fetch FAQs
$stmt = $pdo->prepare("SELECT * FROM faqs ORDER BY created_at DESC");
$stmt->execute();
$faqs = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en" class="bg-black text-white font-body">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>FAQs | Son of Grace Exchange</title>

  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/feather-icons"></script>
  <script>
    tailwind.config = {
      theme: {
        extend: {
          colors: {
            gold: '#FFD700',
            black: '#000000',
            white: '#ffffff',
          },
          fontFamily: {
            spaghetti: ['"Pacifico"', 'cursive'],
            body: ['Inter', 'sans-serif'],
          },
        },
      },
    };
  </script>
  <link href="https://fonts.googleapis.com/css2?family=Pacifico&family=Inter:wght@400;600&display=swap" rel="stylesheet">
</head>

<body class="bg-black text-white font-body">
  <!-- Header -->
  <header class="flex items-center justify-between p-4 border-b border-gold">
    <h1 class="font-spaghetti text-gold text-xl">Son of Grace Exchange</h1>
    <a href="more.php" class="text-gold">Back</a>
  </header>

  <!-- Main -->
  <main class="px-4 py-4 space-y-4">
    <h2 class="text-lg font-semibold text-gold">Frequently Asked Questions</h2>

    <?php if (empty($faqs)): ?>
      <p class="text-gray-400">No FAQs available at the moment.</p>
    <?php else: ?>
      <div class="space-y-4">
        <?php foreach ($faqs as $faq): ?>
          <div class="bg-white text-black rounded-lg p-4">
            <button class="w-full flex justify-between items-center font-medium text-left focus:outline-none toggle-faq">
              <span><?= htmlspecialchars($faq['question']) ?></span>
              <i data-feather="chevron-down" class="text-gold faq-icon"></i>
            </button>
            <div class="faq-answer mt-2 hidden text-sm text-gray-700">
              <?= nl2br(htmlspecialchars($faq['answer'])) ?>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </main>

  <!-- Footer Nav -->
  <nav class="fixed bottom-0 left-0 right-0 bg-black border-t border-gold flex justify-around items-center p-2 z-50">
    <a href="dashboard.php" class="flex flex-col items-center"><i data-feather="home"></i><span class="text-xs">Home</span></a>
    <a href="dashboard_profile.php" class="flex flex-col items-center"><i data-feather="user"></i><span class="text-xs">Profile</span></a>
    <a href="support.php" class="flex flex-col items-center"><i data-feather="phone"></i><span class="text-xs">Support</span></a>
    <a href="history.php" class="flex flex-col items-center"><i data-feather="clock"></i><span class="text-xs">History</span></a>
    <a href="more.php" class="flex flex-col items-center text-white font-bold"><i data-feather="menu"></i><span class="text-xs">More</span></a>
  </nav>

  <script>
    feather.replace();

    // FAQ toggle logic
    document.querySelectorAll(".toggle-faq").forEach(button => {
      button.addEventListener("click", () => {
        const answer = button.nextElementSibling;
        const icon = button.querySelector('.faq-icon');

        answer.classList.toggle("hidden");
        icon.classList.toggle("rotate-180");
      });
    });
  </script>
</body>
</html>
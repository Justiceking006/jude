<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
require_once 'connection.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// ✅ Corrected this line (from referred_user_id to referred_id)
$referrals_stmt = $pdo->prepare("SELECT r.*, u.first_name, u.email FROM referrals r
  JOIN users u ON r.referred_id = u.id
  WHERE r.referrer_id = ?
  ORDER BY r.created_at DESC");
$referrals_stmt->execute([$user_id]);
$referrals = $referrals_stmt->fetchAll();

$referral_link = "https://judesonofgraceexchange.com/register.php?ref=" . $user_id;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Referrals | Son of Grace Exchange</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/feather-icons"></script>
  <script>
    tailwind.config = {
      theme: {
        extend: {
          colors: {
            gold: '#FFD700',
            black: '#000000',
            white: '#ffffff',
          },
          fontFamily: {
            spaghetti: ['"Pacifico"', 'cursive'],
            body: ['Inter', 'sans-serif'],
          },
        },
      },
    }
  </script>
  <link href="https://fonts.googleapis.com/css2?family=Pacifico&family=Inter:wght@400;600&display=swap" rel="stylesheet">
</head>
<body class="bg-black text-white font-body">
  <!-- Header -->
  <header class="flex items-center justify-between p-4 border-b border-gold">
    <h1 class="font-spaghetti text-gold text-xl">Son of Grace Exchange</h1>
    <a href="dashboard.php" class="text-gold">Back</a>
  </header>

  <main class="px-4 py-3 space-y-6">
    <section>
      <h2 class="text-lg font-semibold text-gold mb-2">Your Referral Link</h2>
      <div class="flex items-center justify-between bg-white text-black p-3 rounded-lg">
        <input id="refLink" type="text" value="<?= htmlspecialchars($referral_link) ?>" readonly class="w-full bg-transparent focus:outline-none">
        <button onclick="copyLink()" class="ml-3 text-sm text-blue-600">Copy</button>
      </div>
    </section>

    <section>
      <h2 class="text-lg font-semibold text-gold mb-2">Your Downlines</h2>
      <?php if (empty($referrals)): ?>
        <p class="text-gray-400">No referrals yet.</p>
      <?php else: ?>
        <div class="space-y-3">
          <?php foreach ($referrals as $r): ?>
            <div class="bg-white text-black rounded-lg p-3">
              <div class="flex justify-between">
                <div>
                  <p class="font-semibold capitalize">Name: <?= htmlspecialchars($r['first_name']) ?></p>
                  <p class="text-sm text-gray-600">Email: <?= htmlspecialchars($r['email']) ?></p>
                </div>
                <div class="text-right">
                  <p class="text-sm text-gray-600">Status: <?= htmlspecialchars($r['status']) ?></p>
                  <p class="text-sm text-gray-600">Earnings: ₦<?= number_format($r['earnings'], 2) ?></p>
                </div>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </section>
  </main>

  <!-- Footer -->
  <nav class="fixed bottom-0 left-0 right-0 bg-black border-t border-gold flex justify-around items-center p-2 z-50">
    <a href="dashboard.php" class="nav-item flex flex-col items-center">
      <i data-feather="home"></i><span class="text-xs">Home</span>
    </a>
    <a href="dashboard_profile.php" class="nav-item flex flex-col items-center">
      <i data-feather="user"></i><span class="text-xs">Profile</span>
    </a>
    <a href="support.php" class="nav-item flex flex-col items-center">
      <i data-feather="phone"></i><span class="text-xs">Support</span>
    </a>
    <a href="history.php" class="nav-item flex flex-col items-center">
      <i data-feather="clock"></i><span class="text-xs">History</span>
    </a>
    <a href="more.php" class="nav-item flex flex-col items-center text-white font-bold">
      <i data-feather="menu"></i><span class="text-xs">More</span>
    </a>
  </nav>

  <script>
    feather.replace();
    function copyLink() {
      const input = document.getElementById("refLink");
      input.select();
      input.setSelectionRange(0, 99999);
      navigator.clipboard.writeText(input.value).then(() => {
        alert("Referral link copied!");
      });
    }
  </script>
</body>
</html>
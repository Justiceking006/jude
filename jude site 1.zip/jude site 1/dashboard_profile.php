<?php
session_start();
require_once 'connection.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Fetch user data
$user_stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$user_stmt->execute([$user_id]);
$user = $user_stmt->fetch();

$update_success = false;
$update_error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_profile'])) {
        $new_name = trim($_POST['name']);
        if ($new_name) {
            $stmt = $pdo->prepare("UPDATE users SET first_name = ? WHERE id = ?");
            if ($stmt->execute([$new_name, $user_id])) {
                $update_success = true;
                $user['first_name'] = $new_name;
            } else {
                $update_error = 'Failed to update name.';
            }
        }
    }

    if (isset($_POST['update_password'])) {
        $current_password = $_POST['current_password'];
        $new_password = $_POST['new_password'];
        $confirm_password = $_POST['confirm_password'];

        if (password_verify($current_password, $user['password'])) {
            if ($new_password === $confirm_password) {
                $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
                if ($stmt->execute([$hashed_password, $user_id])) {
                    $update_success = true;
                } else {
                    $update_error = 'Password update failed.';
                }
            } else {
                $update_error = 'New passwords do not match.';
            }
        } else {
            $update_error = 'Current password is incorrect.';
        }
    }
}
?><!DOCTYPE html><html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Profile | Son of Grace Exchange</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/feather-icons"></script>
  <script>
    tailwind.config = {
      theme: {
        extend: {
          colors: {
            gold: '#FFD700',
            black: '#000000',
            white: '#ffffff',
          },
          fontFamily: {
            spaghetti: ['"Pacifico"', 'cursive'],
            body: ['Inter', 'sans-serif'],
          },
        },
      },
    };
  </script>
  <link href="https://fonts.googleapis.com/css2?family=Pacifico&family=Inter:wght@400;600&display=swap" rel="stylesheet">
</head>
<body class="bg-black text-white font-body">
  <!-- Header -->
  <header class="flex items-center justify-between p-4 border-b border-gold">
    <h1 class="font-spaghetti text-gold text-xl">Son of Grace Exchange</h1>
    <a href="dashboard.php" class="text-gold">Back</a>
  </header>  <!-- Main Content -->  <main class="p-4 space-y-6">
    <?php if ($update_success): ?>
      <div class="bg-green-500 text-white p-2 rounded">Update successful.</div>
    <?php elseif ($update_error): ?>
      <div class="bg-red-500 text-white p-2 rounded"><?= htmlspecialchars($update_error) ?></div>
    <?php endif; ?><section>
  <h2 class="text-lg font-semibold text-gold mb-2">Update Name</h2>
  <form method="POST" class="space-y-4">
    <input type="text" name="name" value="<?= htmlspecialchars($user['first_name']) ?>" class="w-full p-2 rounded bg-white text-black" required>
    <button type="submit" name="update_profile" class="bg-gold text-black px-4 py-2 rounded">Update Name</button>
  </form>
</section>

<section>
  <h2 class="text-lg font-semibold text-gold mb-2">Change Password</h2>
  <form method="POST" class="space-y-4">
    <input type="password" name="current_password" placeholder="Current Password" class="w-full p-2 rounded bg-white text-black" required>
    <input type="password" name="new_password" placeholder="New Password" class="w-full p-2 rounded bg-white text-black" required>
    <input type="password" name="confirm_password" placeholder="Confirm New Password" class="w-full p-2 rounded bg-white text-black" required>
    <button type="submit" name="update_password" class="bg-gold text-black px-4 py-2 rounded">Change Password</button>
  </form>
</section>

  </main>  <!-- Footer Navigation -->  <nav class="fixed bottom-0 left-0 right-0 bg-black border-t border-gold flex justify-around items-center p-2 z-50">
    <a href="dashboard.php" class="nav-item flex flex-col items-center"><i data-feather="home"></i><span class="text-xs">Home</span></a>
    <a href="dashboard_profile.php" class="nav-item flex flex-col items-center text-white font-bold"><i data-feather="user"></i><span class="text-xs">Profile</span></a>
    <a href="support.php" class="nav-item flex flex-col items-center"><i data-feather="phone"></i><span class="text-xs">Support</span></a>
    <a href="history.php" class="nav-item flex flex-col items-center"><i data-feather="clock"></i><span class="text-xs">History</span></a>
    <a href="more.php" class="nav-item flex flex-col items-center"><i data-feather="menu"></i><span class="text-xs">More</span></a>
  </nav>  <script>
    feather.replace();
  </script></body>
</html>
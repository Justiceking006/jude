<?php
session_start();
require_once 'connection.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Get user info to prefill
$stmt = $pdo->prepare("SELECT first_name, phone, email FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();
$name = $user['first_name'] ?? '';
$phone = $user['phone'] ?? '';
$email = $user['email'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>POS Request | Son of Grace Exchange</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/feather-icons"></script>
  <script>
    tailwind.config = {
      theme: {
        extend: {
          colors: {
            gold: '#FFD700',
            black: '#000000',
            white: '#ffffff',
          },
          fontFamily: {
            spaghetti: ['"Pacifico"', 'cursive'],
            body: ['Inter', 'sans-serif'],
          },
        },
      },
    };
  </script>
</head>
<body class="bg-black text-white font-body">

  <!-- ✅ Header -->
  <header class="flex items-center justify-between p-4 border-b border-gold">
    <h1 class="text-xl font-spaghetti text-gold">Son of Grace Exchange</h1>
    <a href="dashboard.php" class="text-gold text-sm">Back</a>
  </header>

  <!-- ✅ Info & Form Section -->
  <main class="p-4 pb-32 space-y-6">
    <!-- ✅ Explanation Section -->
    <section class="bg-gold text-black rounded-xl p-4 space-y-2">
      <h2 class="text-lg font-bold">📦 Need a POS Machine?</h2>
      <p>Son of Grace Exchange now offers <strong>Moniepoint POS terminals</strong> for business owners and agents across Nigeria.</p>
      <ul class="list-disc list-inside text-sm">
        <li>✅ Instant settlement</li>
        <li>✅ Low charges</li>
        <li>✅ Reliable nationwide delivery</li>
        <li>✅ Works with our wallet system</li>
      </ul>
      <p class="text-sm mt-2">Fill the form below and our admin will contact you via WhatsApp to complete your request.</p>
    </section>

    <!-- ✅ POS Request Form -->
    <form method="POST" class="space-y-4">
      <input type="text" name="name" value="<?= htmlspecialchars($name) ?>" placeholder="Your Full Name" class="w-full p-2 rounded bg-white text-black" required />
      <input type="text" name="phone" value="<?= htmlspecialchars($phone) ?>" placeholder="Phone Number" class="w-full p-2 rounded bg-white text-black" required />
      <input type="email" name="email" value="<?= htmlspecialchars($email) ?>" placeholder="Email Address" class="w-full p-2 rounded bg-white text-black" required />
      <input type="text" name="business" placeholder="Business Name" class="w-full p-2 rounded bg-white text-black" required />

      <button type="submit" name="request" class="w-full bg-gold text-black py-2 px-4 rounded font-semibold hover:bg-yellow-500 transition">
        Submit & Contact Admin
      </button>
    </form>
  </main>

  <!-- ✅ Bottom Navigation -->
  <nav class="fixed bottom-0 left-0 right-0 bg-black border-t border-gold flex justify-around items-center h-16 p-2 z-50">
    <a href="dashboard.php" class="flex flex-col items-center text-white"><i data-feather="home"></i><span class="text-xs">Home</span></a>
    <a href="dashboard_profile.php" class="flex flex-col items-center"><i data-feather="user"></i><span class="text-xs">Profile</span></a>
    <a href="support.php" class="flex flex-col items-center"><i data-feather="phone"></i><span class="text-xs">Support</span></a>
    <a href="history.php" class="flex flex-col items-center"><i data-feather="clock"></i><span class="text-xs">History</span></a>
    <a href="more.php" class="flex flex-col items-center"><i data-feather="menu"></i><span class="text-xs">More</span></a>
  </nav>

  <script>
    feather.replace();
  </script>

<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['request'])) {
    $name = trim($_POST['name']);
    $phone = trim($_POST['phone']);
    $email = trim($_POST['email']);
    $business = trim($_POST['business']);

    // Save to DB
    $stmt = $pdo->prepare("INSERT INTO pos_requests (user_id, name, phone, email, business_name, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
    $stmt->execute([$user_id, $name, $phone, $email, $business]);

    // WhatsApp Redirect
    $msg = rawurlencode("📦 POS MACHINE REQUEST\n\nName: $name\nPhone: $phone\nEmail: $email\nBusiness Name: $business\n\nPlease follow up with this request.");
    $adminWhatsApp = "+2348108255139"; // 👈🏽 Replace with real admin number
    echo "<script>window.location.href='https://wa.me/$adminWhatsApp?text=$msg';</script>";
    exit;
}
?>
</body>
</html>
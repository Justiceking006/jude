<?php
session_start();
require_once 'connection.php';

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit;
}

$message = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['csv_file'])) {
    $file = $_FILES['csv_file']['tmp_name'];

    if ($_FILES['csv_file']['type'] !== 'text/csv' && pathinfo($_FILES['csv_file']['name'], PATHINFO_EXTENSION) !== 'csv') {
        $message = "Please upload a valid .csv file.";
    } else {
        $handle = fopen($file, 'r');

        // Skip the header
        fgetcsv($handle);

        $count = 0;

        while (($data = fgetcsv($handle, 1000, ',')) !== FALSE) {
            [$category, $network, $plan_name, $type, $service_id, $user_price, $reseller_price, $api_user_price, $validity, $unit_type, $status] = $data;

            // Check if service_id already exists
            $check = $pdo->prepare("SELECT id FROM services WHERE service_id = ?");
            $check->execute([$service_id]);
            if ($check->rowCount() > 0) {
                // Update existing
                $update = $pdo->prepare("UPDATE services SET 
                    category = ?, network = ?, plan_name = ?, type = ?, 
                    user_price = ?, reseller_price = ?, api_user_price = ?, 
                    validity = ?, unit_type = ?, status = ? WHERE service_id = ?");
                $update->execute([
                    $category, $network, $plan_name, $type,
                    $user_price, $reseller_price, $api_user_price,
                    $validity, $unit_type, $status, $service_id
                ]);
            } else {
                // Insert new
                $insert = $pdo->prepare("INSERT INTO services 
                    (category, network, plan_name, type, service_id, user_price, reseller_price, api_user_price, validity, unit_type, status)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $insert->execute([
                    $category, $network, $plan_name, $type, $service_id,
                    $user_price, $reseller_price, $api_user_price,
                    $validity, $unit_type, $status
                ]);
            }

            $count++;
        }

        fclose($handle);
        $message = "Successfully imported/updated $count services.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Upload Vendor CSV</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen p-6 text-gray-800">
  <div class="max-w-2xl mx-auto bg-white shadow-lg rounded-xl p-6">
    <h2 class="text-2xl font-bold mb-4">Upload Service Pricing CSV</h2>

    <?php if ($message): ?>
      <div class="mb-4 p-3 bg-green-100 text-green-800 rounded"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>

    <form action="" method="POST" enctype="multipart/form-data" class="space-y-4">
      <div>
        <label class="block text-sm mb-1">CSV File</label>
        <input type="file" name="csv_file" accept=".csv" required
               class="w-full px-4 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-yellow-500">
      </div>
      <button type="submit"
              class="bg-yellow-500 hover:bg-yellow-600 text-black px-6 py-2 rounded font-semibold">
        Upload and Import
      </button>
    </form>

    <div class="mt-6 text-sm text-gray-600">
      ✅ Expected headers:  
      <code>category, network, plan_name, type, service_id, user_price, reseller_price, api_user_price, validity, unit_type, status</code>
    </div>
  </div>
</body>
</html>
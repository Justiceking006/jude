<?php
session_start();
require_once 'connection.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
// Fetch user name
$stmt = $pdo->prepare("SELECT first_name FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$row = $stmt->fetch();
$name = $row['first_name'] ?? 'User';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Gift Card Trade | Son of Grace Exchange</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/feather-icons"></script>
  <script>
    tailwind.config = {
      theme: {
        extend: {
          colors: {
            gold: '#FFD700',
            black: '#000000',
            white: '#ffffff',
          },
          fontFamily: {
            spaghetti: ['"Pacifico"', 'cursive'],
            body: ['Inter', 'sans-serif'],
          },
        },
      },
    };
  </script>
</head>
<body class="bg-black text-white font-body">

<!-- ✅ Header -->
<header class="flex items-center justify-between p-4 border-b border-gold">
  <h1 class="text-xl font-spaghetti text-gold">Son of Grace Exchange</h1>
  <a href="dashboard.php" class="text-gold">Back</a>
</header>

<!-- ✅ Main -->
<main class="p-4 pb-32 space-y-6">
  <section class="space-y-2">
    <h2 class="text-lg font-semibold text-gold">🎁 Trade Your Gift Cards Easily</h2>
    <p class="text-sm text-white">Need to sell your Amazon, Steam, iTunes, or other gift cards? Fill the form below and we’ll reach out fast! 🚀</p>
  </section>

  <form id="giftForm" class="space-y-4">
    <input type="text" id="full_name" class="w-full p-2 rounded bg-white text-black" placeholder="Full Name" required>
    <input type="tel" id="phone" class="w-full p-2 rounded bg-white text-black" placeholder="Phone Number" required>
    <input type="text" id="card_type" class="w-full p-2 rounded bg-white text-black" placeholder="Type of Gift Card (e.g., Amazon)" required>
    <input type="text" id="card_value" class="w-full p-2 rounded bg-white text-black" placeholder="Card Value (₦ or $)" required>
    <textarea id="note" rows="3" class="w-full p-2 rounded bg-white text-black" placeholder="Additional Note (Optional)"></textarea>
    <button type="submit" class="w-full bg-gold text-black py-2 px-4 rounded font-semibold hover:bg-yellow-500 transition">
      Submit & Contact Admin
    </button>
  </form>
</main>

<!-- ✅ Bottom Navigation -->
<nav class="fixed bottom-0 left-0 right-0 bg-black border-t border-gold flex justify-around items-center p-2 z-50">
  <a href="dashboard.php" class="flex flex-col items-center"><i data-feather="home"></i><span class="text-xs">Home</span></a>
  <a href="dashboard_profile.php" class="flex flex-col items-center"><i data-feather="user"></i><span class="text-xs">Profile</span></a>
  <a href="support.php" class="flex flex-col items-center"><i data-feather="phone"></i><span class="text-xs">Support</span></a>
  <a href="history.php" class="flex flex-col items-center"><i data-feather="clock"></i><span class="text-xs">History</span></a>
  <a href="more.php" class="flex flex-col items-center"><i data-feather="menu"></i><span class="text-xs">More</span></a>
</nav>

<!-- ✅ JavaScript -->
<script>
  feather.replace();

  const form = document.getElementById('giftForm');
  form.addEventListener('submit', function(e) {
    e.preventDefault();
    const name = document.getElementById('full_name').value;
    const phone = document.getElementById('phone').value;
    const card = document.getElementById('card_type').value;
    const value = document.getElementById('card_value').value;
    const note = document.getElementById('note').value;

    const message = `🎁 New Gift Card Trade Request\n\nName: ${name}\nPhone: ${phone}\nCard Type: ${card}\nCard Value: ${value}\nNote: ${note || 'None'}\n\nSent from Son of Grace Exchange`;

    // ✅ Optional: Insert into DB (via AJAX or PHP script) – Not handled here

    // ✅ Open WhatsApp
    const whatsappNumber = '+2348108255139'; // change to your admin number
    const url = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(message)}`;
    window.location.href = url;
  });
</script>
</body>
</html>
<?php
// ✅ Show errors during development (disable in production)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
require_once 'connection.php';

// 🔧 Generate unique referral code
function generateReferralCode($pdo) {
    do {
        $code = strtoupper(substr(str_shuffle("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 6));
        $stmt = $pdo->prepare("SELECT id FROM users WHERE referral_code = ?");
        $stmt->execute([$code]);
    } while ($stmt->fetch());
    return $code;
}

// 🔧 Redirect with error
function redirectWithError($msg) {
    header("Location: register.php?error=" . urlencode($msg));
    exit;
}

// ✅ Handle only POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirectWithError("Invalid request method.");
}

// ✅ Get and validate input
$firstName = trim($_POST['first_name'] ?? '');
$mobile = trim($_POST['mobile'] ?? '');
$email = trim($_POST['email'] ?? '');
$password = $_POST['password'] ?? '';
$confirmPassword = $_POST['confirm_password'] ?? '';
$referrer_code = trim($_POST['referral'] ?? '');

if (!$firstName || !$mobile || !$email || !$password || !$confirmPassword) {
    redirectWithError("All fields are required.");
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    redirectWithError("Invalid email format.");
}
if ($password !== $confirmPassword) {
    redirectWithError("Passwords do not match.");
}

// 🔍 Check uniqueness
$stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? OR phone = ?");
$stmt->execute([$email, $mobile]);
if ($stmt->fetch()) {
    redirectWithError("Email or phone already exists.");
}

// ✅ Insert new user
$hashedPassword = password_hash($password, PASSWORD_DEFAULT);
$referral_code = generateReferralCode($pdo);

$stmt = $pdo->prepare("INSERT INTO users (first_name, phone, email, password, referral_code, created_at)
                       VALUES (?, ?, ?, ?, ?, NOW())");
$stmt->execute([$firstName, $mobile, $email, $hashedPassword, $referral_code]);
$new_user_id = $pdo->lastInsertId();

// ✅ Create empty wallet (optional, you can also create after first payment)
$stmt = $pdo->prepare("INSERT INTO wallets (user_id, balance, created_at)
                       VALUES (?, 0.00, NOW())");
$stmt->execute([$new_user_id]);

// ✅ Send welcome notification
$pdo->prepare("INSERT INTO notifications (user_id, title, message)
               VALUES (?, '🎉 Welcome to Son of Grace Exchange!', ?)")
    ->execute([$new_user_id, "Hi $firstName, your account has been created."]);

// ✅ Handle referral if any
if (!empty($referrer_code)) {
    $stmt = $pdo->prepare("SELECT id FROM users WHERE referral_code = ?");
    $stmt->execute([$referrer_code]);
    if ($referrer = $stmt->fetch()) {
        $pdo->prepare("INSERT INTO referrals (referrer_id, referred_id, created_at)
                       VALUES (?, ?, NOW())")
            ->execute([$referrer['id'], $new_user_id]);
    }
}

// ✅ Done
header("Location: login.php");
exit;
?>
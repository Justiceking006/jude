<!DOCTYPE html>
<html lang="en" class="bg-black text-white font-body">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Login | Son of Grace Exchange</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    tailwind.config = {
      theme: {
        extend: {
          colors: {
            gold: '#FFD700',
            black: '#000000',
            white: '#ffffff',
          },
          fontFamily: {
            spaghetti: ['"Pacifico"', 'cursive'],
            body: ['Inter', 'sans-serif'],
          },
        },
      },
    };
  </script>
  <link href="https://fonts.googleapis.com/css2?family=Pacifico&family=Inter:wght@400;600&display=swap" rel="stylesheet">
</head>
<body class="bg-black text-white font-body">

<main class="flex items-center justify-center min-h-screen px-4">
  <div class="w-full max-w-md bg-black p-8 rounded-lg border border-gold shadow-md">
    <h2 class="text-2xl font-bold text-gold text-center mb-6">Welcome Back</h2>

    <!-- Display login error if present -->
    <?php if (isset($_GET['error'])): ?>
      <div class="bg-red-600 text-white text-sm px-4 py-2 rounded mb-4 text-center">
        <?= htmlspecialchars($_GET['error']) ?>
      </div>
    <?php endif; ?>

    <form action="login_script.php" method="POST" class="space-y-4">
      <div>
        <label for="email" class="block text-sm mb-1">Email</label>
        <input type="email" name="email" id="email"
               class="w-full px-3 py-2 bg-transparent border-b border-gold text-white focus:outline-none" required />
      </div>

      <div class="relative">
        <label for="password" class="block text-sm mb-1">Password</label>
        <input type="password" name="password" id="password"
               class="w-full px-3 py-2 bg-transparent border-b border-gold text-white focus:outline-none pr-10" required />
        <button type="button" class="absolute top-7 right-2 text-gold toggle-password" data-target="password">
          <i data-feather="eye"></i>
        </button>
      </div>

      <button type="submit" name="login"
              class="w-full bg-gold text-black py-2 font-bold rounded hover:bg-yellow-400 transition">
        Login
      </button>
    </form>

    <p class="mt-4 text-sm text-center">
      Don’t have an account?
      <a href="register.php" class="underline text-white hover:text-gold transition">Register here</a>
    </p>
  </div>
</main>

<script src="https://unpkg.com/feather-icons"></script>
<script>
  feather.replace();
  document.querySelectorAll('.toggle-password').forEach(button => {
    button.addEventListener('click', () => {
      const input = document.getElementById(button.dataset.target);
      const isPassword = input.getAttribute('type') === 'password';
      input.setAttribute('type', isPassword ? 'text' : 'password');
      button.innerHTML = isPassword
        ? feather.icons["eye-off"].toSvg()
        : feather.icons["eye"].toSvg();
    });
  });
</script>
</body>
</html>